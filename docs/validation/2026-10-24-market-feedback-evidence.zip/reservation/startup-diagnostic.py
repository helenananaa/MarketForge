import sys,json,copy
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from research_market_mechanisms import run_one,write
from analyze_market_mechanisms import analyze_run,bar_metrics,sha
from analyze_basis_execution import candles
out=root/'.local/strategy-research-reservation-20261024';study=out/'startup-diagnostic';study.mkdir(exist_ok=True)
plan=json.loads((out/'plan.json').read_text())
row=dict(plan['runs'][1],name='startup-s41-reservation',steps=7200,warmup_ms=600000)
write(study/'diagnostic-plan.json',dict(row=row,scope='Additional startup diagnostic, minutes 10–120. Does not replace the frozen 12h runs or claim post-warmup qualification. No parameter changes.'))
run=run_one(study,row,out/'candidate.exe',1200);assert run['complete']
r=analyze_run(study,row)
control=plan['controls'][0];source=Path(control['metrics']).parent
comparison={}
for market in ('V-BTC-SPOT','V-BTC-PERP'):
    comparison[market]=dict(control=bar_metrics(candles(source/(control['name']+'-'+market+'.candles.csv')),600000,7200000),candidate=r['markets'][market]['minute'])
write(study/'startup-comparison.json',dict(scope='Minutes 10–120 only, still inside the primary studies\' warmup window',markets=comparison))
print(json.dumps({m:{arm:{k:v[k] for k in ('return_std_bp','return_acf1','abs_return_p99_bp')} for arm,v in x.items()} for m,x in comparison.items()}),flush=True)
