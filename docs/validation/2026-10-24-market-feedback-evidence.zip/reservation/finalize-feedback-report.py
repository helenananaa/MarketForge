import json,shutil,sys
from pathlib import Path
root=Path.cwd();directory=root/'.local/strategy-research-reservation-20261024';basis=root/'.local/strategy-research-basis-20261024'
sys.path.insert(0,str(root/'scripts'))
from analyze_market_mechanisms import sha,write
x=json.loads((directory/'summary/feedback-summary.json').read_text(encoding='utf-8'))
report=root/'docs/validation/2026-10-24-market-feedback.md'
text=report.read_text(encoding='utf-8')
labels={'baseline':'原始 touch（背景参照）','model_ack':'旧 model_ack（配对对照）','executable':'可执行套利','reservation':'报价偏移变化'}
lines=['## 完整结果（2026-10-25 汇总）','',
'10 次新增完整运行全部成功：8 次候选运行、2 次旧策略复跑，共 120 个模拟小时。',
'两份种子 41 旧策略回执均与上一轮完整回执逐字节一致。没有删除种子或失败结果。','',
'**两项策略均不提升为默认。** 可执行套利缺乏跨种子稳定性；报价偏移变化缓解了大幅波动，',
'但持续产生过强的分钟反转和长影线。当前结果不足以称为真实市场。','',
'以下是四个种子各自统计量的算术平均，不是把收益序列合并后的统计：','',
'| 市场 | 策略 | 1m 收益标准差 bp | 1m 绝对收益 P99 bp | 双边盘口 % | 中位价差 bp | 5m 中位影线占比 |',
'|---|---|---:|---:|---:|---:|---:|']
for a in x['aggregate']:
 m=a['mean'];lines.append(f"| {a['market'].replace('V-BTC-','')} | {labels[a['profile']]} | {m['return_std_bp']:.2f} | {m['abs_return_p99_bp']:.2f} | {m['two_sided_pct']:.2f} | {m['spread_median_bp']:.2f} | {m['wick_5m']:.3f} |")
lines+=['','逐种子主要结果如下；每格为“分钟收益标准差 bp / lag-1 自相关 / 绝对收益 P99 bp”：','',
'| 市场 | 种子 | 旧 model_ack | 可执行套利 | 报价偏移变化 |','|---|---:|---:|---:|---:|']
for market in ('V-BTC-SPOT','V-BTC-PERP'):
 for seed in (7,19,41,73):
  cells=[]
  for profile in ('model_ack','executable','reservation'):
   r=next(r for r in x['rows'] if r['market']==market and r['seed']==seed and r['profile']==profile)
   cells.append(f"{r['return_std_bp']:.2f} / {r['return_acf1']:+.3f} / {r['abs_return_p99_bp']:.2f}")
  lines.append(f"| {market.replace('V-BTC-','')} | {seed} | "+' | '.join(cells)+' |')
lines+=['',
'可执行套利使平均套利主动成交占比从现货 38.3%、永续 33.8% 降至 1.8%、1.1%。',
'它消除了部分不可执行的交易机会，但同时改变了价格传导。种子 73 现货波动从',
'32.48 升至 56.07 bp，永续从 28.75 升至 34.39 bp；种子 7 永续出现约 7.4% 的实际下探。',
'这一方案不能凭种子 41 的改善判为成功。','',
'报价偏移变化使四个种子、两个市场的波动及绝对收益 P99 均较 model_ack 下降，',
'平均标准差现货下降 56.9%、永续下降 63.0%。但是现货自相关仍在 −0.498 至 −0.366，',
'永续在 −0.494 至 −0.132；现货 5m 中位影线占比平均 0.764，未比旧对照 0.762 改善。',
'种子 41 的 12% 泡沫消失，但分钟图仍明显来回振荡；种子 73 后段再现长影线。',
'种子 19 的永续标准差仅 2.29 bp，低于本轮所有历史 10h 窗口，也不能把越平稳当作越真实。','',
'原始 touch 的平均标准差为现货 4.02、永续 5.83 bp，仍低于两项新候选。',
'其双边盘口更差，部分种子自相关也异常；它同样没有通过完整真实性验证。','',
'### 同长度真实窗口的描述性范围','',
'| 市场 | 1m 标准差 bp | 1m 自相关 | 1m 绝对收益 P99 bp | 5m 中位影线占比 |',
'|---|---:|---:|---:|---:|']
for market in ('V-BTC-SPOT','V-BTC-PERP'):
 rows=[r for r in x['reference_windows'] if r['market']==market]
 cells=[]
 for k in ('return_std_bp','return_acf1','abs_return_p99_bp','wick_5m'):
  cells.append(f"{min(r[k] for r in rows):.3f}–{max(r[k] for r in rows):.3f}")
 lines.append(f"| {market.replace('V-BTC-','')} | "+' | '.join(cells)+' |')
lines+=['',
'事后增加的跨市场检查也显示约束不足。历史 8 个窗口的现货/永续分钟收益相关性为',
'0.978–0.998；可执行套利为 0.026–0.653，报价偏移变化为 0.070–0.579。',
'可执行套利种子 7 的分钟收盘价绝对基差最大约 710 bp，历史参考最大约 8.2 bp。',
'这里对齐的是两边的分钟成交收盘价，既不是同一瞬间的可执行报价，也不能据此计算套利利润。',
'这项检查在看到种子 7 异常后加入，只提供后续诊断方向。','',
'### 图和逐项数据','',
'![全部种子统计](2026-10-24-market-feedback-statistics.png)','',
'![报价偏移变化，种子41完整5分钟K线](2026-10-24-market-feedback-reservation-seed41.png)','',
'![可执行套利，种子73恶化](2026-10-24-market-feedback-basis-seed73.png)','',
'全部种子的完整 5m 图和最后两小时 1m 图均保存在两个原始实验目录和证据 ZIP 中，',
'没有只保留表现好的种子。[逐种子汇总 CSV](2026-10-24-market-feedback-comparison.csv)。','']
old='## 待完整运行后写入的结果\n\n结果尚在汇总，不能据此报告通过。'
assert old in text
text=text.replace(old,'\n'.join(lines))
verification='''已通过 `cargo test -p exchange-core --lib`：452 passed、0 failed、12 ignored；
独立报价反馈示例测试 1 项通过；配方和分析 Python 测试 12 项通过。
版本、恢复、拒单、部分对冲、真实网关挂单确认、同一时刻幂等及旧配方保持均有覆盖。
测试通过只说明实现契约，没有把统计失败改写成市场通过。

两个冻结可执行文件的 SHA-256：

- 可执行套利：`0182f0d33df9c3aeeac1d1eb3b5e450d12897dbcf27cce320be245d80a3d43c3`
- 报价偏移变化：`62867d4ef2abc39efeb85e3388aae6d403ac76e28cca6a1b04b916a931545a46`

原始控制回执 SHA-256：
`802e008a14836aa743a1a8bf5303b6134ea4e8bb3ebe28152004d8e4cf25dde6`。
两组完整复跑都得到该值。原始上一轮证据 ZIP 保持不变。

[本轮证据 ZIP](2026-10-24-market-feedback-evidence.zip) 包含冻结计划、配方、运行元数据、
各项统计、实际 OHLCV、全部图、构建/测试日志、诊断输出、参考校验和与当前源码快照。
大体积原始回执和冻结二进制留在 `.local/strategy-research-basis-20261024` 与
`.local/strategy-research-reservation-20261024`，文件身份见 ZIP 的 MANIFEST。
套利二进制先于报价偏移代码构建，因此当前源码快照同时包含两项可选实现，
不宣称能从当前源码获得逐字节相同的旧二进制。复制计划复现时需使用新输出目录。

本轮代码和报告保留在工作区，未提交或推送。两项策略仍需显式选择。

## 下一步应验证的机制

优先增加日内因果轨迹：记录报价参考、库存/资金预算、目标价、实际挂撤单确认、
对冲残差和成交触发来源，并贯穿单次异常波段，区分库存风险调整、主动追价与强平。
同时检查跨市场对冲为何在大基差时仍不能恢复联系，以及观测流截断是否改变真实信号。
这些都有当前异常证据支持；单纯缩小波动或影线不应作为下一轮目标。'''
text=text.replace('待全部运行与验证完成后补齐。',verification)
report.write_text(text,encoding='utf-8')
for source,name in [(directory/'summary/feedback-all-seeds.png','statistics.png'),(directory/'reservation-seed41-candles-5m-full.png','reservation-seed41.png'),(basis/'basis-seed73-candles-5m-full.png','basis-seed73.png'),(directory/'summary/feedback-summary.csv','comparison.csv')]:
 shutil.copyfile(source,report.with_name('2026-10-24-market-feedback-'+name))
print('Wrote report and copied verified figures/data')
