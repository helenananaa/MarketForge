import sys,json
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from research_market_mechanisms import run_one,write
out=root/'.local/strategy-research-reservation-20261024';smoke=out/'smoke';smoke.mkdir(exist_ok=True)
plan=json.loads((out/'plan.json').read_text());control=plan['runs'][0];candidate=plan['runs'][1]
def run(name,row,binary):
    return run_one(smoke,dict(row,name=name,steps=600,warmup_ms=0),binary,300)
old=run('legacy-old',control,root/'.local/strategy-research-basis-20261024/candidate.exe')
new=run('legacy-new',control,out/'candidate.exe')
treatment=run('reservation-new',candidate,out/'candidate.exe')
assert all(r['complete'] for r in (old,new,treatment))
assert old['receipt_sha256']==new['receipt_sha256']
write(out/'smoke-compatibility.json',dict(steps=600,old=old,new=new,treatment=treatment,legacy_byte_identical=True))
