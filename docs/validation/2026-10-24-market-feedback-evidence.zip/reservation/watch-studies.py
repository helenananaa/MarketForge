import os,sys,time,json,subprocess
from pathlib import Path
root=Path.cwd();base=root/'.local/strategy-research-basis-20261024';reservation=root/'.local/strategy-research-reservation-20261024'
env=dict(os.environ,PYTHONPATH=str(reservation/'analysis-deps'))
seen={base:1,reservation:0};finished=set()
while len(finished)<2:
    for out in (base,reservation):
        if out in finished:continue
        count=len(list(out.glob('native-*.run.json')))
        if count>seen[out]:
            log=out/f'analysis-pass-{count}.log'
            with log.open('w',encoding='utf-8') as f:
                result=subprocess.run([sys.executable,str(root/'scripts/analyze_basis_execution.py'),'--output',str(out),'--charts'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
            if result.returncode:raise RuntimeError(str(log))
            seen[out]=count
            data=json.loads((out/'basis-comparison.json').read_text())
            print(json.dumps(dict(study=out.name,attempts=count,complete=data['complete'],terminal=data['terminal'],compatibility=data['compatibility'],pairs=[dict(seed=p['seed'],spot_std=p['candidate']['markets']['V-BTC-SPOT']['minute']['return_std_bp'],perp_std=p['candidate']['markets']['V-BTC-PERP']['minute']['return_std_bp']) for p in data['pairs']])),flush=True)
            if data['terminal']:finished.add(out)
    time.sleep(10)
