"""Package completed evidence; keep raw receipts and executables in place."""
import hashlib,json,zipfile,sys
from datetime import datetime
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from analyze_market_mechanisms import sha,write
from research_market_mechanisms import ensure_runtime_inputs
studies={name:root/f'.local/strategy-research-{name}-20261024' for name in ('basis','reservation')}
original=root/'.local/strategy-research-mechanisms-20261024'
records=[];files={};raw=[];checks={}
def include(path,arcname):
    assert path.is_file(),str(path)
    files[arcname]=path
for name,directory in studies.items():
    plan=json.loads((directory/'plan.json').read_text())
    comparison=json.loads((directory/'basis-comparison.json').read_text())
    assert comparison['complete'] and len(comparison['pairs'])==4 and comparison['compatibility']['byte_identical']
    assert comparison['plan_sha256']==sha(directory/'plan.json')
    ensure_runtime_inputs(directory,plan['runs'])
    verification=dict(verified_at=datetime.now().astimezone().isoformat(),runtime_inputs_unchanged=True,manifest_sha256=sha(directory/'runtime-inputs.json'),phase='final package validation')
    with (directory/'runtime-verifications.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(verification)+'\n')
    checks[name]=dict(plan_sha256=sha(directory/'plan.json'),binary_sha256=sha(directory/'candidate.exe'),complete_runs=comparison['completed_runs'],compatibility=comparison['compatibility'])
    for row in plan['runs']:
        run=json.loads((directory/(row['name']+'.run.json')).read_text())
        assert run['complete'] and sha(Path(row['recipe']))==row['recipe_sha256']==run['inputs']['recipe_sha256']
        receipt=directory/(row['name']+'.receipt.json')
        assert sha(receipt)==run['receipt_sha256']
        assert run['inputs']['binary_sha256']==checks[name]['binary_sha256']
        raw.append(dict(path=str(receipt),sha256=run['receipt_sha256'],bytes=receipt.stat().st_size))
    raw.append(dict(path=str(directory/'candidate.exe'),sha256=checks[name]['binary_sha256'],bytes=(directory/'candidate.exe').stat().st_size))
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.json','.jsonl','.csv','.png','.log','.ps1','.py') and not path.name.endswith('.receipt.json') and path.name not in ('package-feedback.py','package.log','package-verification.json'):
            include(path,name+'/'+path.name)
    for folder in ('reference-calendar','smoke','startup-diagnostic','summary'):
        for path in (directory/folder).glob('*'):
            if path.is_file() and path.suffix in ('.json','.csv','.png','.log','.CHECKSUM') and not path.name.endswith('.receipt.json'):
                include(path,name+'/'+folder+'/'+path.name)
    for control in plan['controls']:
        for key in ('recipe','metrics'):
            path=Path(control[key]);assert sha(path)==control[key+'_sha256'];include(path,'prior-controls/'+path.name)
        path=Path(control['receipt']);assert sha(path)==control['receipt_sha256']
        raw.append(dict(path=str(path),sha256=control['receipt_sha256'],bytes=path.stat().st_size))
for seed in (7,19,41,73):
    for profile in ('baseline','model_ack'):
        for pattern in (f'native-s{seed}-{profile}.metrics.json',f'native-s{seed}-{profile}.run.json',f'native-s{seed}-{profile}.recipe.json',f'native-s{seed}-{profile}-*.candles.csv'):
            for path in original.glob(pattern):include(path,'prior-controls/'+path.name)
for name in ('plan.json','analysis-environment.json','runtime-inputs.json','reference-statistics.json'):
    include(original/name,'prior-controls/'+name)
reference=json.loads((studies['reservation']/'reference-calendar/calendar-reference.json').read_text(encoding='utf-8'))
reference_verified=[]
for row in reference['records']:
    path=Path(row['source']['path']);assert sha(path)==row['source']['sha256']
    reference_verified.append(dict(path=str(path),sha256=row['source']['sha256'],bytes=path.stat().st_size))
write(studies['reservation']/'reference-calendar/final-verification.json',dict(verified_at=datetime.now().astimezone().isoformat(),archives=reference_verified))
include(studies['reservation']/'reference-calendar/final-verification.json','reservation/reference-calendar/final-verification.json')
assert sha(root/'docs/validation/2026-10-24-market-mechanisms-evidence.zip')=='2e7df9279d0fcc5d067edb0d050ce0782d9f6a18ce7abf94b2be734cd065f93c'
sources=['README.md','exchange-core/src/adaptive_liquidity.rs','exchange-core/src/basis_link.rs','exchange-core/examples/maker_reference_probe.rs',
 'scripts/strategy_ecosystem.py','scripts/research_market_mechanisms.py','scripts/analyze_market_mechanisms.py','scripts/research_basis_execution.py',
 'scripts/research_quote_reservation.py','scripts/analyze_basis_execution.py','scripts/summarize_market_feedback.py','scripts/research_flow_visibility.py',
 'scripts/analyze_market_anomaly.py','scripts/market_reference_calendar.py',
 'python/tests/test_market_mechanism_analysis.py','python/tests/test_market_mechanism_recipe.py','python/tests/test_basis_execution_analysis.py','python/tests/test_basis_execution_recipe.py',
 'docs/MARKET_MECHANISM_EXPERIMENTS.md','docs/MARKET_QUOTE_FEEDBACK_EXPERIMENTS.md','docs/validation/2026-10-24-market-feedback.md']
sources.extend('docs/validation/2026-10-24-market-feedback-'+name for name in ('statistics.png','reservation-seed41.png','basis-seed73.png','comparison.csv'))
for name in sources:include(root/name,'source/'+name)
include(Path(__file__),'source/package-feedback.py')
for arcname,path in sorted(files.items()):records.append(dict(path=arcname,bytes=path.stat().st_size,sha256=sha(path)))
manifest=dict(recorded_at=datetime.now().astimezone().isoformat(),head='3167ded3ceca11c80bdbb9293a01861a371887be',studies=checks,
 records=records,raw_evidence=list({x['path']:x for x in raw}.values()),
 scope='Complete independent native-bot ablations. Current source snapshot includes both experimental options; basis binary was built before reservation code was added. Frozen executable hashes are authoritative; no claim of bit-identical rebuild from current sources. Runtime-input hashes were rechecked at package time. Raw receipts and binaries remain in their local evidence directories, not in this compact ZIP. Reference ZIP archives remain at paths recorded in reference-calendar metrics, with published checksums in the ZIP. Original mechanism study archive remains unchanged.')
destination=root/'docs/validation/2026-10-24-market-feedback-evidence.zip'
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    z.writestr('README.txt','Read source/docs/validation/2026-10-24-market-feedback.md and source/docs/MARKET_QUOTE_FEEDBACK_EXPERIMENTS.md first. Recipes, plans, run metadata, actual candles, analyses, figures, diagnostic outputs, test/build logs and reference checksums are preserved. Raw authoritative receipts, frozen executables and historical ZIPs remain at the local paths recorded in the manifest and reference metadata. To reproduce elsewhere, restore the documented repository and dependencies, keep all original files unchanged, copy plans to NEW directories and remap only file paths while preserving recipe bytes. Record any copied plan hash. Do not reuse completed run metadata with a rebuilt executable. The two treatments are independent, not combined.\n')
    for arcname,path in sorted(files.items()):z.write(path,arcname)
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))==len(records)+2
    for record in records:assert hashlib.sha256(z.read(record['path'])).hexdigest()==record['sha256']
result=dict(archive=str(destination),sha256=sha(destination),bytes=destination.stat().st_size,members=len(records)+2,crc_and_member_sha256_verified=True,studies=checks)
write(studies['reservation']/'package-verification.json',result)
print(json.dumps(result,indent=2))
