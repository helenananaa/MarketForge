"""Read the completed raw receipt while batch metadata awaits admission resume."""
import json,sys
from collections import defaultdict
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from analyze_market_mechanisms import add_bar,bar_metrics,rebar,quoted_mid_metrics,sha,write
from analyze_causal_mechanisms import morphology,market_link
base=root/'.local/strategy-research-causal-20261025';path=base/'inventory-level-study/native-s41-level.receipt.json'
data=json.loads(path.read_text(encoding='utf-8-sig'));assert data['steps']==43200 and data['simulation_time_ms']==43200000 and data['bots']==300
bars=defaultdict(dict);snapshots=defaultdict(list)
for t in data['trade_receipts']:
    if t['time_ms']<43200000:add_bar(bars[t['instrument_id']],t['time_ms'],t['price_tick'],t['qty'])
for s in data['book_snapshots']:
    if 7200000<=s['time_ms']<43200000:snapshots[s['instrument_id']].append(s)
records={market:dict(minute=bar_metrics(bs,7200000,43200000),quoted_mid_minute=quoted_mid_metrics(snapshots[market],7200000,43200000,1000),
    morphology_5m=morphology(rebar(bs,5),7200000,43200000,300000),
    primary_price_range=[min(b['low'] for k,b in bs.items() if 120<=k<720),max(b['high'] for k,b in bs.items() if 120<=k<720)]) for market,bs in bars.items()}
result=dict(receipt_sha256=sha(path),markets=records,market_link=market_link(bars['V-BTC-SPOT'],bars['V-BTC-PERP'],7200000,43200000),
    scope='Diagnostic preview only of the fully written, schema-validated 43200-step raw seed41 receipt. The native child has exited; the batch launcher is paused to serialize admission, so its original .run.json is not yet written. No run metadata is invented or replaced. Final statistics require the ordinary runner metadata and matching full receipt SHA. All seeds/treatments remain frozen regardless of this preview.')
write(base/'level41-raw-preview.json',result)
print(json.dumps(dict(receipt_sha256=result['receipt_sha256'],markets={m:{'std':v['minute']['return_std_bp'],'acf':v['minute']['return_acf1'],'quote_mid_acf':v['quoted_mid_minute']['return_acf1'],'wick':v['morphology_5m']['median_wick_fraction'],'close_change_pct':v['minute']['close_change_pct'],'primary_price_range':v['primary_price_range']} for m,v in records.items()},market_link=result['market_link']),indent=2))
