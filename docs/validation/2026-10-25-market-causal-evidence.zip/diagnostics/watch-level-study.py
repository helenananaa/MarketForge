import json,os,sys,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'.local/strategy-research-causal-20261025/inventory-level-study'
env=dict(os.environ,PYTHONPATH=str(root/'.local/strategy-research-reservation-20261024/analysis-deps'));seen=0
while True:
    count=len(list(out.glob('native-*.run.json')))
    if count>seen:
        with (out/f'analysis-pass-{count}.log').open('w',encoding='utf-8') as log:
            result=subprocess.run([sys.executable,str(root/'scripts/analyze_inventory_level_study.py')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        assert result.returncode==0,f'analysis-pass-{count}.log'
        data=json.loads((out/'causal-comparison.json').read_text(encoding='utf-8'));seen=count
        print(json.dumps({k:data[k] for k in ('completed_runs','complete','terminal','compatibility')}),flush=True)
        if data['terminal']:break
    time.sleep(12)
