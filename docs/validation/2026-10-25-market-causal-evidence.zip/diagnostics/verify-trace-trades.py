"""Verify each final trace fill against its independently emitted receipt window."""
import csv,json,sys,gc
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from analyze_market_mechanisms import sha,write
base=root/'.local/strategy-research-causal-20261025';checks=[]
keys=('trade_id','time_ms','price_tick','qty','taker_account_id','taker_order_id','maker_account_id')
for folder,receipt,start,end in [('control-analysis-v3','trace-s41-control-v2',9000000,9660000),
    ('hedged-analysis-v3','diagnostic-s41-hedged',9000000,9660000),('depth-analysis-v3','diagnostic-s41-depth',9000000,9660000),
    ('remaining-depth-analysis-v3','remaining-depth-s41',10620000,11280000),('inventory-level-pilot-analysis-v3','inventory-level-pilot-s41',10620000,11280000)]:
    path=base/(receipt+'.receipt.json');csv_path=base/folder/'trades.csv';data=json.loads(path.read_text(encoding='utf-8-sig'))
    actual=[(t['instrument_id'],*[int(t[k]) for k in keys],t['taker_side']) for t in data['trade_receipts'] if start<=t['time_ms']<end]
    del data;gc.collect()
    with csv_path.open(encoding='utf-8') as f:trace=[(r['market'],*[int(r[k]) for k in keys],r['taker_side']) for r in csv.DictReader(f)]
    assert len(trace)==len({(r[0],r[1]) for r in trace}),'Repeated authoritative trace trade ID'
    assert actual==trace,folder+': ordered trace/native fill mismatch'
    checks.append(dict(folder=folder,window_ms=[start,end],trades=len(trace),ordered_fill_identity_equal=True,unique_market_trade_ids=True,
        receipt_sha256=sha(path),trace_csv_sha256=sha(csv_path),compared_fields=['instrument_id',*keys,'taker_side']))
    print(folder,len(trace),'exact ordered fills',flush=True)
write(base/'trace-native-fill-verification.json',dict(records=checks,scope='Every final selected-window authoritative fill is compared in order to the independently emitted native receipt, including market/trade ID, timestamp, price, quantity, maker/taker account, taker order and side. Native receipts do not expose gateway command IDs or maker order IDs; those extra trace fields are not independently verified by this check.'))
