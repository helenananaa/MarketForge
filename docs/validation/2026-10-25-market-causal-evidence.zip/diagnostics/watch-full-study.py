import json,os,subprocess,sys,time
from pathlib import Path
root=Path.cwd();out=root/'.local/strategy-research-causal-20261025/full-study'
env=dict(os.environ,PYTHONPATH=str(root/'.local/strategy-research-reservation-20261024/analysis-deps'))
seen=0
while True:
    count=len(list(out.glob('native-*.run.json')))
    if count>seen:
        with (out/f'analysis-pass-{count}.log').open('w',encoding='utf-8') as log:
            result=subprocess.run([sys.executable,str(root/'scripts/analyze_causal_mechanisms.py'),'--charts'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        assert result.returncode==0,f'analysis-pass-{count}.log'
        comparison=json.loads((out/'causal-comparison.json').read_text(encoding='utf-8'))
        print(json.dumps({k:comparison[k] for k in ('completed_runs','complete','terminal','compatibility')}),flush=True)
        seen=count
        if comparison['terminal']:break
    time.sleep(12)
