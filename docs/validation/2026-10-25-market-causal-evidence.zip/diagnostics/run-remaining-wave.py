import json,sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from research_causal_trace import run
from analyze_causal_trace import analyze
from analyze_market_mechanisms import sha,write
out=root/'.local/strategy-research-causal-20261025';full=out/'full-study'
s=json.loads((out/'early-remaining-wave-selection.json').read_text(encoding='utf-8'))
name='remaining-depth-s41';recipe=full/'native-s41-depth.recipe.json'
run(out,name,full/'candidate.exe',recipe,s['steps'],f"{s['start_ms']}:{s['end_ms']}")
now=json.loads((out/(name+'.receipt.json')).read_text(encoding='utf-8'))
prior=json.loads((full/'native-s41-depth.receipt.json').read_text(encoding='utf-8'))
for key in ('trade_receipts','book_snapshots'):assert now[key]==[r for r in prior[key] if r['time_ms']<=now['simulation_time_ms']],key
write(out/'remaining-depth-prefix-verification.json',dict(prefix_trade_and_book_equal=True,source_receipt_sha256=sha(full/'native-s41-depth.receipt.json'),replay_receipt_sha256=sha(out/(name+'.receipt.json')),selection_sha256=sha(out/'early-remaining-wave-selection.json')))
del now,prior
r=analyze(out/(name+'.trace.jsonl'),recipe,out/'remaining-depth-analysis-v3')
assert r['maker_center_max_reconstruction_error']<1e-6,r
print('Remaining early-wave trace verified; original full study unchanged',flush=True)
