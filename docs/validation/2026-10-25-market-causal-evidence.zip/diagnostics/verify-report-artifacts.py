"""Check local report targets, all exported PNGs and the complete seed matrix."""
import csv,json,math,re,sys
from pathlib import Path
from PIL import Image
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from analyze_market_mechanisms import write,sha
base=root/'.local/strategy-research-causal-20261025';report=root/'docs/validation/2026-10-25-market-causal.md'
source=report.read_text(encoding='utf-8');missing=[];targets=[]
for href in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',source):
    if href.startswith(('https://','http://','#')):continue
    target=(report.parent/href).resolve();targets.append(str(target))
    if not target.is_file():missing.append(target)
archive=report.parent/'2026-10-25-market-causal-evidence.zip'
assert missing in ([],[archive]),missing
assert not any(word in source for word in ('尚在运行','结果待汇总','将在完成后','TODO'))
pngs=set(report.parent.glob('2026-10-25-market-causal-*.png'))
for study in ('full-study','inventory-level-study','inventory-level-retry-s7'):pngs.update((base/study).glob('*.png'))
for path in pngs:
    with Image.open(path) as im:im.verify()
with (report.parent/'2026-10-25-market-causal-comparison.csv').open(encoding='utf-8') as f:rows=list(csv.DictReader(f))
assert len(rows)==len({(r['seed'],r['profile'],r['market']) for r in rows})==32
for row in rows:
    assert int(row['primary_actual_minute_bars'])==int(row['primary_expected_minute_bars'])==600
    for key in ('return_std_bp','return_acf1','quote_mid_acf1','wick_5m','two_sided_pct'):assert math.isfinite(float(row[key]))
data=json.loads((base/'combined-comparison.json').read_text(encoding='utf-8'))
assert data['completed_new_runs']==13 and data['total_new_native_attempts']==14 and not any(a['missing'] for a in data['aggregates'])
write(base/'report-artifact-verification.json',dict(report_sha256=sha(report),local_targets=len(targets),checked_pngs=len(pngs),seed_market_profile_rows=32,
    all_primary_minute_bars=600,missing_statistic_fields=False,archive_not_yet_created=bool(missing),
    scope='Structural/PNG verification complements visual inspection of every seed full-window comparison, trace figure and combined statistics. The evidence ZIP is the only permitted not-yet-created target before packaging.'))
print('Report targets,',len(pngs),'PNGs and all 32 seed/market/profile rows verified',flush=True)
