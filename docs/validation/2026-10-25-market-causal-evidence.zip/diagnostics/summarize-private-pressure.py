"""Descriptive quote-pressure audit in the fixed remaining-wave window."""
import csv,json,sys
from collections import Counter
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from analyze_market_mechanisms import write,sha
base=root/'.local/strategy-research-causal-20261025';records=[]
for profile,folder in [('depth','remaining-depth-analysis-v3'),('level','inventory-level-pilot-analysis-v3')]:
    directory=base/folder
    with (directory/'maker-decisions.csv').open(encoding='utf-8') as f:makers=list(csv.DictReader(f))
    with (directory/'trades.csv').open(encoding='utf-8') as f:trades=list(csv.DictReader(f))
    for market in ('V-BTC-SPOT','V-BTC-PERP'):
        rs=[r for r in makers if r['market']==market and r['reconsidered']=='True'];n=len(rs)
        mids={int(r['time_ms']):float(r['book_mid']) for r in makers if r['market']==market and r['book_mid']}
        signed=Counter();volume=Counter()
        for r in trades:
            if r['market']==market:
                signed[r['taker_role']]+=int(r['qty'])*(1 if r['taker_side']=='Buy' else -1)
                volume[r['taker_role']]+=int(r['qty'])
        avg=lambda fn:sum(fn(r) for r in rs)/n
        records.append(dict(profile=profile,market=market,reconsiderations=n,
            mean_inventory_error_lots=avg(lambda r:float(r['inventory_error'])),
            underweight_fraction=avg(lambda r:float(r['inventory_error'])<0),overweight_fraction=avg(lambda r:float(r['inventory_error'])>0),
            mean_raw_inventory_bias_tick=avg(lambda r:float(r['inventory_bias'])),
            mean_reference_bias_tick=avg(lambda r:float(r['reference_bias'])),
            mean_private_before_clamp_tick=avg(lambda r:float(r['reservation_offset'])-float(r['previous_offset']) if profile=='depth' else float(r['inventory_bias'])+float(r['reference_bias'])),
            mean_flow_before_clamp_tick=avg(lambda r:float(r['flow_impact'])),
            mean_actual_center_minus_reference_tick=avg(lambda r:float(r['center'])-float(r['mid'])),
            first_quote_mid=mids[min(mids)],last_quote_mid=mids[max(mids)],
            quote_mid_change_pct=(mids[max(mids)]/mids[min(mids)]-1)*100,
            actual_net_taker_qty_by_role=dict(signed),actual_taker_qty_by_role=dict(volume),source_csv_sha256=sha(directory/'maker-decisions.csv')))
write(base/'remaining-private-pressure.json',dict(records=records,
    scope='Descriptive averages of actual maker reconsideration observations, unweighted across makers/refreshes, not independent samples or a regression/causal attribution. Proposals include cancel-only/rejected cases; no claim that all centers became two-sided displayed quotes. Aggregate signed flow uses each authoritative fill once; pending flow is not summed across makers. Same selected window, different endogenous inventories and markets.'))
print(json.dumps(records,indent=2))
