import json,sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from research_causal_trace import run
from analyze_market_mechanisms import write,sha
from analyze_causal_trace import analyze
out=root/'.local/strategy-research-causal-20261025';full=out/'full-study';binary=full/'candidate.exe'
plan=json.loads((full/'plan.json').read_text(encoding='utf-8'));control=full/'native-s41-control.recipe.json'
off=run(out,'candidate-smoke-off',binary,control,600)
on=run(out,'candidate-smoke-on',binary,control,600,'450000:600001')
prior=json.loads((root/'.local/strategy-research-reservation-20261024/smoke-compatibility.json').read_text(encoding='utf-8'))['treatment']['receipt_sha256']
assert off['receipt_sha256']==on['receipt_sha256']==prior
write(out/'candidate-smoke-compatibility.json',dict(byte_identical=True,prior_sha256=prior,new_sha256=off['receipt_sha256'],binary_sha256=sha(binary),plan_sha256=sha(full/'plan.json')))
for profile in ('hedged','depth'):
    recipe=full/f'native-s41-{profile}.recipe.json';name=f'diagnostic-s41-{profile}'
    run(out,name,binary,recipe,plan['diagnostics']['steps'],plan['diagnostics']['windows'])
    result=analyze(out/(name+'.trace.jsonl'),recipe,out/('diagnostic-'+profile+'-analysis'))
    assert result['maker_center_max_reconstruction_error']<1e-6,result
print('Frozen candidate diagnostics complete; no retuning',flush=True)
