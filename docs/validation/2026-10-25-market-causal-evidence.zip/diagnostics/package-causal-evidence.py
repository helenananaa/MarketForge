"""Verify and package final causal evidence, keeping multi-GB raw files local."""
import hashlib,json,sys,zipfile
from datetime import datetime
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from analyze_market_mechanisms import write

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
from research_market_mechanisms import ensure_runtime_inputs
base=root/'.local/strategy-research-causal-20261025';files={};raw={};checks={}
def include(path,name):
    assert path.is_file(),str(path)
    if name in files:assert sha(files[name])==sha(path),name
    files[name]=path
def raw_file(path):
    assert path.is_file(),str(path)
    raw[str(path.resolve())]=dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=sha(path))
for label,directory,expected in [('main',base/'full-study',9),('inventory-level',base/'inventory-level-study',3),('inventory-level-retry-s7',base/'inventory-level-retry-s7',1)]:
    plan=json.loads((directory/'plan.json').read_text(encoding='utf-8'));comparison=json.loads((directory/'causal-comparison.json').read_text(encoding='utf-8'))
    assert comparison['terminal'] and comparison['completed_runs']==expected
    if label=='inventory-level':
        assert not comparison['complete'] and len(comparison['failures'])==1
        assert comparison['failures'][0]['name']=='native-s7-level' and comparison['failures'][0]['exit_code']==4294967295
        assert (directory/'resource-cancel-s7.json').is_file()
    else:assert comparison['complete'] and not comparison['failures']
    assert comparison['plan_sha256']==sha(directory/'plan.json')
    binary=sha(directory/'candidate.exe');assert binary=='2ba563200bda1baca2191b064ae935db18bd9b4f04c0b1f78833283decdfb926'
    ensure_runtime_inputs(directory,plan['runs'])
    runtime_check=dict(verified_at=datetime.now().astimezone().isoformat(),phase='final package',runtime_inputs_unchanged=True,manifest_sha256=sha(directory/'runtime-inputs.json'))
    with (directory/'runtime-verifications.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(runtime_check)+'\n')
    checks[label]=dict(successful_full_runs=expected,attempts=len(plan['runs']),complete=comparison['complete'],retained_failed_attempts=comparison['failures'],plan_sha256=sha(directory/'plan.json'),binary_sha256=binary,compatibility=comparison['compatibility'])
    for row in plan['runs']:
        run=json.loads((directory/(row['name']+'.run.json')).read_text(encoding='utf-8'))
        assert run['inputs']['binary_sha256']==binary and run['inputs']['recipe_sha256']==row['recipe_sha256']==sha(Path(row['recipe']))
        receipt=directory/(row['name']+'.receipt.json')
        if run['complete']:assert sha(receipt)==run['receipt_sha256']
        else:assert label=='inventory-level' and row['name']=='native-s7-level' and run['exit_code']==4294967295
        raw_file(receipt)
    for control in plan['controls']:
        for kind in ('recipe','metrics','receipt'):assert sha(Path(control[kind]))==control[kind+'_sha256']
        for kind in ('recipe','metrics'):include(Path(control[kind]),'controls/'+Path(control[kind]).name)
        raw_file(Path(control['receipt']))
    raw_file(directory/'candidate.exe')
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.json','.jsonl','.csv','.png','.log','.ps1') and not path.name.endswith('.receipt.json'):
            include(path,label+'/'+path.name)
    for path in (directory/'compiled-source').rglob('*'):
        if path.is_file():include(path,label+'/compiled-source/'+path.relative_to(directory/'compiled-source').as_posix())
manifest=json.loads((base/'full-study/compiled-inputs.json').read_text(encoding='utf-8'))
for row in manifest['files']:
    assert sha(root/row['path'])==row['sha256']==sha(base/'full-study/compiled-source'/row['path']),row['path']
for path in base.iterdir():
    if not path.is_file():continue
    if path.name.endswith(('.receipt.json','.trace.jsonl')) or path.suffix=='.exe':raw_file(path);continue
    if path.name in ('agent-progress.json','package.log','package-verification.json'):continue
    if path.suffix in ('.json','.jsonl','.csv','.png','.log','.py'):include(path,'diagnostics/'+path.name)
for folder in ('control-analysis-v3','hedged-analysis-v3','depth-analysis-v3','remaining-depth-analysis-v3','inventory-level-pilot-analysis-v3'):
    for path in (base/folder).iterdir():
        if path.name=='gateway-accounts.json':raw_file(path)
        elif path.is_file() and path.suffix in ('.json','.csv','.png','.log'):include(path,'diagnostics/'+folder+'/'+path.name)
for folder in ('prechange-source','analysis-sources'):
    for path in (base/folder).rglob('*'):
        if path.is_file():include(path,'diagnostics/'+folder+'/'+path.relative_to(base/folder).as_posix())
excerpt=base/'anomaly-analysis/maker17-excerpt.json';include(excerpt,'diagnostics/original-maker17-excerpt.json')
reference=root/'.local/strategy-research-reservation-20261024'
raw_file(reference/'candidate.exe')
assert sha(reference/'candidate.exe')=='62867d4ef2abc39efeb85e3388aae6d403ac76e28cca6a1b04b916a931545a46'
include(reference/'summary/feedback-summary.json','reference/prior-feedback-summary.json')
include(reference/'quote-feedback-mixed-probe.json','reference/prior-quote-feedback-mixed-probe.json')
include(reference/'quote-feedback-mixed-probe.log','reference/prior-quote-feedback-mixed-probe.log')
calendar=json.loads((reference/'reference-calendar/calendar-reference.json').read_text(encoding='utf-8'))
for record in calendar['records']:
    path=Path(record['source']['path']);assert sha(path)==record['source']['sha256'];raw_file(path)
for path in (reference/'reference-calendar').iterdir():
    if path.suffix in ('.json','.CHECKSUM'):include(path,'reference/calendar/'+path.name)
prior_archives={
 '2026-10-24-market-mechanisms-evidence.zip':'2e7df9279d0fcc5d067edb0d050ce0782d9f6a18ce7abf94b2be734cd065f93c',
 '2026-10-24-market-feedback-evidence.zip':'0e000afe851fba640d7f2eb4c0e326ed05865e4990771158c750e0fc5a55024e'}
for name,expected in prior_archives.items():assert sha(root/'docs/validation'/name)==expected
source_names=['README.md','exchange-core/src/adaptive_liquidity.rs','exchange-core/src/basis_link.rs','exchange-core/examples/strategy_market.rs','exchange-core/examples/maker_reference_probe.rs','exchange-core/examples/support/research_trace.rs','exchange-core/examples/support/research_audit.rs','exchange-core/examples/support/research_checkpoint.rs','exchange-server/examples/strategy_ecosystem_market.rs',
 'scripts/strategy_ecosystem.py','scripts/research_market_mechanisms.py','scripts/analyze_market_mechanisms.py','scripts/analyze_basis_execution.py','scripts/summarize_market_feedback.py','scripts/research_basis_execution.py','scripts/research_causal_trace.py','scripts/research_causal_mechanisms.py','scripts/analyze_causal_trace.py','scripts/analyze_causal_mechanisms.py','scripts/summarize_causal_window.py','scripts/summarize_remaining_wave.py','scripts/summarize_causal_studies.py','scripts/audit_causal_flow_observations.py','scripts/research_inventory_level_study.py','scripts/analyze_inventory_level_study.py',
 'python/tests/test_causal_mechanisms_recipe.py','python/tests/test_inventory_level_recipe.py','python/tests/test_basis_execution_recipe.py','python/tests/test_basis_execution_analysis.py','python/tests/test_market_mechanism_recipe.py','python/tests/test_market_mechanism_analysis.py',
 'scripts/research_quote_reservation.py','scripts/research_flow_visibility.py','scripts/market_reference_calendar.py','scripts/background_market.py',
 'docs/MARKET_CAUSAL_EXPERIMENTS.md','docs/MARKET_QUOTE_FEEDBACK_EXPERIMENTS.md','docs/validation/2026-10-25-market-causal.md']
for name in source_names:include(root/name,'source/'+name)
for path in (root/'docs/validation').glob('2026-10-25-market-causal-*.png'):include(path,'source/docs/validation/'+path.name)
for path in (root/'docs/validation').glob('2026-10-25-market-causal-*.csv'):include(path,'source/docs/validation/'+path.name)
records=[dict(path=name,bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(files.items())]
consolidated=json.loads((base/'combined-comparison.json').read_text(encoding='utf-8'))
assert consolidated['completed_new_runs']==13 and consolidated['total_new_native_attempts']==14 and len(consolidated['cancelled_attempts'])==1 and len(consolidated['summary'])==32
for study,expected_sha in consolidated['study_hashes'].items():assert sha(base/study/'causal-comparison.json')==expected_sha
trace_check=json.loads((base/'trace-native-fill-verification.json').read_text(encoding='utf-8'))
assert len(trace_check['records'])==5 and all(r['ordered_fill_identity_equal'] and r['unique_market_trade_ids'] for r in trace_check['records'])
for r in trace_check['records']:assert sha(base/r['folder']/'trades.csv')==r['trace_csv_sha256']
retry_prefix=json.loads((base/'cancelled-retry-prefix-verification.json').read_text(encoding='utf-8'))
assert retry_prefix['inputs_identical'] and retry_prefix['through_step']==22200 and retry_prefix['cumulative_trade_and_active_bot_counts_equal']
verification=dict(recorded_at=datetime.now().astimezone().isoformat(),overall_resolved_complete=True,completed_full_runs=13,total_fullstudy_attempts=14,retained_partial_cancellations=1,studies=checks,records=records,raw_evidence=list(raw.values()),prior_archives_unchanged=prior_archives,
    scope='14 full-study native attempts (diagnostic smokes/replays separate): 13 new complete runs (156 full simulated hours) and one explicitly resource-cancelled seed7 partial attempt with last logged step22200, preserved in its original directory. Progress is logged every100 steps, so the exact unrecorded stop step is unknown. A separately frozen serial retry uses its identical recipe/executable; all four seed outcomes retained. Raw full receipts, traces, large gateway arrays, executables and historical ZIPs stay at the hashed local paths. The compact ZIP contains numerical inputs, derived final traces/candles, every seed figure, build/test/error logs and source snapshots. Earlier exploratory intermediate analysis directories remain local; source version2 is preserved and final trace facts use corrected version3, including cancel-only reconsiderations. No independent holdout, historical order-book or live/Pine qualification.')
destination=root/'docs/validation/2026-10-25-market-causal-evidence.zip'
assert not destination.exists(),'Preserve the existing evidence archive'
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('MANIFEST.json',json.dumps(verification,indent=2)+'\n')
    z.writestr('README.txt','Start with source/docs/validation/2026-10-25-market-causal.md and source/docs/MARKET_CAUSAL_EXPERIMENTS.md. Main and inventory-level are separate frozen designs; the second uses already completed depth controls and the identical executable. A seed7 partial attempt was explicitly cancelled for commit headroom and remains failed in its original metadata; inventory-level-retry-s7 contains its serial full retry using identical inputs. All four successful seed outcomes are consolidated; 14 attempts, 13 full successes. No old plan, recipe, binary or run metadata was changed to reuse a name. Large authoritative evidence remains local at the hashed paths in MANIFEST.json. To reproduce elsewhere, restore the recorded repository/source/dependency identities, copy plans into NEW directories, remap file paths while preserving recipe bytes, and record all copied plan hashes. Do not reuse completed run metadata with a different executable. Raw price paths were never injected, smoothed or filled.\n')
    for name,path in sorted(files.items()):z.write(path,name)
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(records)+2
    for row in records:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
result=dict(archive=str(destination),sha256=sha(destination),bytes=destination.stat().st_size,members=len(records)+2,crc_and_all_member_sha256_verified=True,overall_resolved_complete=True,completed_full_runs=13,total_fullstudy_attempts=14,retained_partial_cancellations=1,studies=checks)
write(base/'package-verification.json',result);print(json.dumps(result,indent=2))
