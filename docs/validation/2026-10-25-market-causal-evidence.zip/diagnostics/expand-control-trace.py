import json,sys,time
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from research_causal_trace import run
from analyze_causal_trace import analyze
from analyze_market_mechanisms import write,sha
out=root/'.local/strategy-research-causal-20261025';full=out/'full-study'
while not (out/'diagnostic-s41-depth.run.json').exists():time.sleep(3)
selection=json.loads((out/'selection.json').read_text(encoding='utf-8'))
write(out/'control-trace-expansion.json',dict(reason='Record all visible external liquidity levels with the final tracer, so maker impact can also be compared against observed market depth in the unchanged anomaly state.',scope='Additional diagnostic only: same archived control, seed, selected time window, numerical inputs and prefix. No plan, candidate or evaluation-window change.',selection_sha256=sha(out/'selection.json')))
name='trace-s41-control-v2';recipe=full/'native-s41-control.recipe.json'
run(out,name,full/'candidate.exe',recipe,selection['steps'],f"{selection['start_ms']}:{selection['end_ms']}")
assert sha(out/(name+'.receipt.json'))==sha(out/'trace-s41-reservation.receipt.json')
write(out/'control-trace-v2-compatibility.json',dict(full_prefix_receipt_byte_identical=True,receipt_sha256=sha(out/(name+'.receipt.json')),old_trace_prefix_sha256=sha(out/'trace-s41-reservation.receipt.json')))
for label,trace,recipe in [('control',name,recipe),('hedged','diagnostic-s41-hedged',full/'native-s41-hedged.recipe.json'),('depth','diagnostic-s41-depth',full/'native-s41-depth.recipe.json')]:
    result=analyze(out/(trace+'.trace.jsonl'),recipe,out/(label+'-analysis-v2'))
    assert result['analyzer_schema']==2 and result['maker_center_max_reconstruction_error']<1e-6,result
print('Fresh-process schema-2 analyses complete for all three exact windows',flush=True)
