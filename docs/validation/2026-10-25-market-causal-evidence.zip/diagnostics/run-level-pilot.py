import json,sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from research_causal_trace import run
from analyze_causal_trace import analyze
out=root/'.local/strategy-research-causal-20261025';study=out/'inventory-level-study'
design=json.loads((study/'design.json').read_text(encoding='utf-8'));pilot=design['pilot'];recipe=study/'native-s41-level.recipe.json'
name='inventory-level-pilot-s41'
run(out,name,study/'candidate.exe',recipe,pilot['steps'],pilot['window'])
r=analyze(out/(name+'.trace.jsonl'),recipe,out/'inventory-level-pilot-analysis-v3')
assert r['maker_center_max_reconstruction_error']<1e-6,r
print('Level pilot complete; all four frozen full runs remain scheduled regardless of this result',flush=True)
