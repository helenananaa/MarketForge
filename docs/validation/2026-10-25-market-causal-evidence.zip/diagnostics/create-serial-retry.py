"""Freeze a new attempt for the resource-cancelled seed, preserving the old plan."""
import json,shutil,sys
from datetime import datetime
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from analyze_market_mechanisms import sha,write
from research_market_mechanisms import ensure_runtime_inputs
base=root/'.local/strategy-research-causal-20261025';source=base/'inventory-level-study';out=base/'inventory-level-retry-s7'
assert not out.exists();out.mkdir()
plan=json.loads((source/'plan.json').read_text(encoding='utf-8'));row=next(r for r in plan['runs'] if r['seed']==7)
attempt=json.loads((source/(row['name']+'.run.json')).read_text(encoding='utf-8'))
assert not attempt['complete'] and attempt['exit_code']==4294967295 and (source/'resource-cancel-s7.json').is_file()
assert sha(Path(row['recipe']))==row['recipe_sha256']==attempt['inputs']['recipe_sha256']
shutil.copyfile(source/'candidate.exe',out/'candidate.exe')
assert sha(out/'candidate.exe')==attempt['inputs']['binary_sha256']=='2ba563200bda1baca2191b064ae935db18bd9b4f04c0b1f78833283decdfb926'
ensure_runtime_inputs(out,[row])
write(out/'plan.json',dict(frozen_at=datetime.now().astimezone().isoformat(),original_plan_sha256=sha(source/'plan.json'),original_design_sha256=sha(source/'design.json'),
    original_cancelled_attempt_metadata_sha256=sha(source/(row['name']+'.run.json')),cancel_record_sha256=sha(source/'resource-cancel-s7.json'),
    controls=[r for r in plan['controls'] if r['seed']==7],runs=[row],
    scope='Infrastructure retry only: same previously frozen seed7 recipe, steps and executable, unchanged numerical inputs. Original incomplete attempt was explicitly cancelled for system commit headroom at step22200, and its partial log/failure metadata remain in the original study. This fresh directory runs one native process after the original remaining cases finish. All four seed outcomes still retained; this is not choosing a seed or treatment from market statistics.'))
print('Serial seed7 retry frozen; original cancelled attempt preserved',flush=True)
