$ErrorActionPreference='Stop'
$studyDirectory='E:\projects\MarketForge-tuning\.local\strategy-research-causal-20261025\inventory-level-study'
$nativeExe=Join-Path $studyDirectory 'candidate.exe'
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class SerialAdmission {
 [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint a,bool i,int p);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
 [DllImport("ntdll.dll")] static extern int NtSuspendProcess(IntPtr h);
 [DllImport("ntdll.dll")] static extern int NtResumeProcess(IntPtr h);
 public static void Set(int p,bool pause){var h=OpenProcess(0xD00,false,p);if(h==IntPtr.Zero)throw new Exception("OpenProcess");try{int s=pause?NtSuspendProcess(h):NtResumeProcess(h);if(s!=0)throw new Exception("NT status "+s);}finally{CloseHandle(h);}}
}
'@
$runnerProcess=Get-CimInstance Win32_Process -Filter 'ProcessId=46596'
if(-not $runnerProcess -or $runnerProcess.Name -ne 'python.exe' -or $runnerProcess.CommandLine -notlike '*research_market_mechanisms.py run --output .local/strategy-research-causal-20261025/inventory-level-study --workers 2*'){throw 'Runner identity mismatch'}
$children=@(Get-CimInstance Win32_Process -Filter "ParentProcessId=46596" | Where-Object {$_.ExecutablePath -eq $nativeExe})
if($children.Count -ne 2 -or @($children|Where-Object {$_.CommandLine -notmatch 'native-s(41|19)-level\.recipe\.json'}).Count){throw 'Expected only seed41 and seed19 before pausing admission'}
$pausedRunner=$false
function RecordAdmission($event){@{time=(Get-Date -Format o);event=$event;pid=$runnerProcess.ProcessId;creation_date=$runnerProcess.CreationDate;command=$runnerProcess.CommandLine;children=$children.ProcessId;scope='Pause batch admission only; existing native children and the memory governor continue. Resume after those children exit so seed73 starts alone.'}|ConvertTo-Json -Compress -Depth 4|Add-Content -LiteralPath (Join-Path $studyDirectory 'serial-admission.jsonl')}
try{
 [SerialAdmission]::Set($runnerProcess.ProcessId,$true);$pausedRunner=$true;RecordAdmission 'pause-runner-admission'
 while($true){
  $remaining=@(Get-CimInstance Win32_Process -Filter 'ParentProcessId=46596'|Where-Object {$_.ExecutablePath -eq $nativeExe})
  if($remaining.Count -eq 0){break}
  Start-Sleep -Seconds 2
 }
}finally{
 if($pausedRunner){
  $liveRunner=Get-CimInstance Win32_Process -Filter 'ProcessId=46596' -ErrorAction SilentlyContinue
  if($liveRunner -and $liveRunner.CreationDate -eq $runnerProcess.CreationDate -and $liveRunner.CommandLine -eq $runnerProcess.CommandLine){[SerialAdmission]::Set($runnerProcess.ProcessId,$false);RecordAdmission 'resume-runner-admission'}
 }
}
