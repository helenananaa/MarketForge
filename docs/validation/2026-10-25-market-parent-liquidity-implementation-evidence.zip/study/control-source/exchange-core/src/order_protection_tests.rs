#[test]
fn conditional_entry_respects_external_pause_and_scheduler_origin() {
    let mut rooms = RoomManager::new();
    rooms
        .create_room(pending_perp_liquidation_scenario("conditional-origin"))
        .unwrap();
    rooms.pause_room("conditional-origin").unwrap();
    let command = Command::SetConditionalOrder {
        account_id: 20,
        key: "pine-entry".into(),
        spec: Some(Box::new(crate::conditional_orders::ConditionalOrderSpec {
            side: Side::Buy,
            position_side: crate::PositionSide::Both,
            qty: 1,
            trigger_price_tick: 110,
            above: true,
            trigger: crate::ProtectionTrigger::Last,
            limit_price_tick: Some(111),
            protection: None,
        })),
    };
    let external = rooms.apply("conditional-origin", command.clone()).unwrap();
    assert!(matches!(
        external.result,
        ActorExecutionResult::Rejected(ActorRejectReason::MarketPaused)
    ));
    let scheduled = rooms
        .apply_to_instrument_from(
            "conditional-origin",
            "V-BTC-PERP",
            command.clone(),
            crate::CommandOrigin::Scheduler,
        )
        .unwrap();
    assert!(matches!(
        scheduled.result,
        ActorExecutionResult::Accepted(_)
    ));
    rooms.close_room("conditional-origin").unwrap();
    let closed = rooms
        .apply_to_instrument_from(
            "conditional-origin",
            "V-BTC-PERP",
            command,
            crate::CommandOrigin::Scheduler,
        )
        .unwrap();
    assert!(matches!(
        closed.result,
        ActorExecutionResult::Rejected(ActorRejectReason::MarketClosed)
    ));
}

fn protected_order(
    id: u64,
    side: Side,
    price: i64,
    qty: u64,
    order_type: crate::model::ProtectedOrderType,
    valid_until: Option<u64>,
    expires: Option<u64>,
) -> Command {
    Command::NewOrder(NewOrder {
        position_side: crate::model::PositionSide::Both,
        order_id: id,
        account_id: 20,
        side,
        qty,
        reduce_only: false,
        kind: OrderKind::Protected {
            order_type,
            price_tick: price,
            valid_until_market_time_ms: valid_until,
            expires_at_market_time_ms: expires,
        },
    })
}

fn spot_events(execution: &crate::ActorExecution) -> Vec<Event> {
    match &execution.result {
        ActorExecutionResult::Accepted(MarketExecution::Spot(result)) => result
            .events
            .iter()
            .map(|record| record.event.clone())
            .collect(),
        other => panic!("unexpected result: {other:?}"),
    }
}

#[test]
fn protection_rejects_old_decisions_at_the_exchange_deadline() {
    use crate::model::ProtectedOrderType::ImmediateOrCancel;
    let mut rooms = RoomManager::new();
    rooms.create_room(spot_scenario("deadline")).unwrap();
    let old_book = rooms.book_snapshot("deadline").unwrap();
    rooms.advance_clock("deadline", 1).unwrap();
    let stale = rooms
        .apply(
            "deadline",
            protected_order(2, Side::Buy, 101, 1, ImmediateOrCancel, Some(1000), None),
        )
        .unwrap();
    assert!(matches!(
        stale.result,
        ActorExecutionResult::Rejected(ActorRejectReason::OrderProtectionExpired {
            deadline_market_time_ms: 1000,
            market_time_ms: 1000
        })
    ));
    assert_eq!(rooms.book_snapshot("deadline").unwrap(), old_book);
    let fresh = rooms
        .apply(
            "deadline",
            protected_order(3, Side::Buy, 101, 1, ImmediateOrCancel, Some(1001), None),
        )
        .unwrap();
    assert!(
        spot_events(&fresh)
            .iter()
            .any(|event| matches!(event, Event::TradePrinted(_)))
    );
}

#[test]
fn protection_price_bound_survives_price_moving_while_deciding() {
    use crate::model::ProtectedOrderType::ImmediateOrCancel;
    let mut rooms = RoomManager::new();
    rooms.create_room(spot_scenario("moving")).unwrap();
    assert_eq!(
        rooms.book_snapshot("moving").unwrap().asks[0].price_tick,
        100
    );
    rooms
        .apply("moving", Command::CancelOrder(CancelOrder { order_id: 1 }))
        .unwrap();
    rooms
        .apply("moving", limit(2, 10, Side::Sell, 120, 5))
        .unwrap();
    let result = rooms
        .apply(
            "moving",
            protected_order(3, Side::Buy, 101, 2, ImmediateOrCancel, None, None),
        )
        .unwrap();
    let events = spot_events(&result);
    assert!(
        !events
            .iter()
            .any(|event| matches!(event, Event::TradePrinted(_)))
    );
    assert!(events.contains(&Event::OrderExpired {
        order_id: 3,
        unfilled_qty: 2
    }));
    assert_eq!(
        rooms.book_snapshot("moving").unwrap().asks[0].price_tick,
        120
    );
}

#[test]
fn protection_ioc_can_partially_fill_without_crossing_the_price_bound() {
    use crate::model::ProtectedOrderType::ImmediateOrCancel;
    let mut scenario = spot_scenario("partial");
    scenario.seed_orders = vec![
        limit(1, 10, Side::Sell, 100, 1),
        limit(2, 10, Side::Sell, 105, 4),
    ];
    let mut rooms = RoomManager::new();
    rooms.create_room(scenario).unwrap();
    let result = rooms
        .apply(
            "partial",
            protected_order(3, Side::Buy, 101, 3, ImmediateOrCancel, Some(5000), None),
        )
        .unwrap();
    let events = spot_events(&result);
    assert_eq!(
        events
            .iter()
            .filter_map(|event| match event {
                Event::TradePrinted(trade) => Some((trade.price_tick, trade.qty)),
                _ => None,
            })
            .collect::<Vec<_>>(),
        vec![(100, 1)]
    );
    assert!(events.contains(&Event::OrderExpired {
        order_id: 3,
        unfilled_qty: 2
    }));
    assert!(rooms.book_snapshot("partial").unwrap().bids.is_empty());
}

#[test]
fn protection_expiry_releases_partial_resting_orders_and_is_replayable() {
    use crate::model::ProtectedOrderType::Limit;
    let mut scenario = spot_scenario("expiry");
    scenario.seed_orders = vec![limit(1, 10, Side::Sell, 100, 1)];
    let mut rooms = RoomManager::new();
    rooms.create_room(scenario).unwrap();
    rooms
        .apply(
            "expiry",
            protected_order(2, Side::Buy, 101, 3, Limit, Some(1000), Some(2000)),
        )
        .unwrap();
    rooms.advance_clock("expiry", 1).unwrap();
    assert_eq!(rooms.book_snapshot("expiry").unwrap().bids[0].qty, 2);
    let saved = serde_json::to_string(rooms.simulation_room("expiry").unwrap()).unwrap();
    let mut restored = RoomManager::new();
    restored
        .restore_simulation_room(serde_json::from_str(&saved).unwrap(), vec![])
        .unwrap();
    for manager in [&mut rooms, &mut restored] {
        manager.advance_clock("expiry", 1).unwrap();
        assert!(manager.book_snapshot("expiry").unwrap().bids.is_empty());
        let observation = manager
            .participant_observation("expiry", "V-BTC-SPOT", 20)
            .unwrap();
        let Some(crate::AccountSnapshot::Spot(account)) = observation.own_account else {
            panic!()
        };
        assert_eq!(account.reserved_cash, 0);
        assert_eq!(account.position_qty, 1);
        let last = manager.execution_history("expiry").unwrap().last().unwrap();
        assert_eq!(last.market_time_ms, 2000);
        assert!(spot_events(last).contains(&Event::OrderExpired {
            order_id: 2,
            unfilled_qty: 2
        }));
        let count = manager.execution_history("expiry").unwrap().len();
        manager.advance_clock("expiry", 1).unwrap();
        assert_eq!(manager.execution_history("expiry").unwrap().len(), count);
    }
    let commands = rooms
        .execution_history("expiry")
        .unwrap()
        .iter()
        .flat_map(|execution| match &execution.result {
            ActorExecutionResult::Accepted(MarketExecution::Spot(result)) => {
                vec![result.command.clone()]
            }
            _ => vec![],
        })
        .collect::<Vec<_>>();
    let replayed = crate::ReplayEngine::replay(&commands);
    assert_eq!(
        replayed.final_snapshot,
        rooms.book_snapshot("expiry").unwrap()
    );
    assert!(replayed.events.iter().any(|record| record.event
        == Event::OrderExpired {
            order_id: 2,
            unfilled_qty: 2
        }));
}

#[test]
fn protection_long_lived_limits_and_post_only_keep_their_semantics() {
    use crate::model::ProtectedOrderType::{ImmediateOrCancel, Limit, PostOnly};
    let mut rooms = RoomManager::new();
    rooms.create_room(spot_scenario("long-lived")).unwrap();
    let rejected = rooms
        .apply(
            "long-lived",
            protected_order(2, Side::Buy, 101, 1, PostOnly, None, Some(5000)),
        )
        .unwrap();
    assert!(spot_events(&rejected).iter().any(|event| matches!(
        event,
        Event::OrderRejected {
            reason: crate::RejectReason::PostOnlyWouldTakeLiquidity,
            ..
        }
    )));
    rooms
        .apply(
            "long-lived",
            protected_order(3, Side::Buy, 95, 1, Limit, None, None),
        )
        .unwrap();
    rooms.advance_clock("long-lived", 10).unwrap();
    assert_eq!(
        rooms.book_snapshot("long-lived").unwrap().bids[0].price_tick,
        95
    );
    let invalid = rooms
        .apply(
            "long-lived",
            protected_order(4, Side::Buy, 101, 1, ImmediateOrCancel, None, Some(20000)),
        )
        .unwrap();
    assert!(matches!(
        invalid.result,
        ActorExecutionResult::Rejected(ActorRejectReason::InvalidOrderProtection)
    ));
}

#[test]
fn protection_expired_sell_cannot_fill_on_the_next_step() {
    use crate::model::ProtectedOrderType::Limit;
    let mut scenario = spot_scenario("sell-expiry");
    scenario.seed_orders.clear();
    let mut rooms = RoomManager::new();
    rooms.create_room(scenario).unwrap();
    let mut sell = protected_order(1, Side::Sell, 100, 2, Limit, None, Some(1000));
    if let Command::NewOrder(order) = &mut sell {
        order.account_id = 10;
    }
    rooms.apply("sell-expiry", sell).unwrap();
    rooms.pause_room("sell-expiry").unwrap();
    rooms.advance_clock("sell-expiry", 1).unwrap();
    assert!(rooms.book_snapshot("sell-expiry").unwrap().asks.is_empty());
    let observation = rooms
        .participant_observation("sell-expiry", "V-BTC-SPOT", 10)
        .unwrap();
    let Some(crate::AccountSnapshot::Spot(account)) = observation.own_account else {
        panic!()
    };
    assert_eq!(account.reserved_position, 0);
}

#[test]
fn protection_reduce_only_respects_minimum_sell_price_and_current_position() {
    use crate::model::ProtectedOrderType::ImmediateOrCancel;
    let mut scenario = pending_perp_liquidation_scenario("reduce-protection");
    scenario.seed_orders = vec![
        limit(1, 10, Side::Sell, 100, 2),
        limit(2, 20, Side::Buy, 100, 2),
        limit(3, 30, Side::Buy, 98, 1),
        limit(4, 30, Side::Buy, 95, 1),
    ];
    let mut rooms = RoomManager::new();
    rooms.create_room(scenario).unwrap();
    let close = |id, price, qty| {
        let mut command = protected_order(
            id,
            Side::Sell,
            price,
            qty,
            ImmediateOrCancel,
            Some(5000),
            None,
        );
        if let Command::NewOrder(order) = &mut command {
            order.reduce_only = true;
        }
        command
    };
    let no_fill = rooms.apply("reduce-protection", close(5, 99, 2)).unwrap();
    let ActorExecutionResult::Accepted(MarketExecution::Perp(no_fill)) = no_fill.result else {
        panic!()
    };
    assert!(
        !no_fill
            .events
            .iter()
            .any(|event| matches!(event.event, Event::TradePrinted(_)))
    );
    let partial = rooms.apply("reduce-protection", close(6, 98, 2)).unwrap();
    let ActorExecutionResult::Accepted(MarketExecution::Perp(partial)) = partial.result else {
        panic!()
    };
    assert!(partial.events.iter().any(|event| matches!(&event.event,
        Event::TradePrinted(trade) if trade.price_tick == 98 && trade.qty == 1)));
    assert!(partial.events.iter().any(|event| event.event
        == Event::OrderExpired {
            order_id: 6,
            unfilled_qty: 1
        }));
    let too_large = rooms.apply("reduce-protection", close(7, 95, 2)).unwrap();
    let ActorExecutionResult::Accepted(MarketExecution::Perp(too_large)) = too_large.result else {
        panic!()
    };
    assert!(too_large.events.iter().any(|event| matches!(
        event.event,
        Event::RiskRejected {
            reason: crate::model::RiskRejectReason::ReduceOnlyExceedsPosition,
            ..
        }
    )));
    let observation = rooms
        .participant_observation("reduce-protection", "V-BTC-PERP", 20)
        .unwrap();
    let Some(crate::AccountSnapshot::Perp(account)) = observation.own_account else {
        panic!()
    };
    assert_eq!(account.position_qty, 1);
}

#[test]
fn protection_perp_expiry_releases_reserved_margin() {
    use crate::model::ProtectedOrderType::Limit;
    let mut rooms = RoomManager::new();
    rooms
        .create_room(pending_perp_liquidation_scenario("perp-expiry"))
        .unwrap();
    rooms
        .apply(
            "perp-expiry",
            protected_order(1, Side::Buy, 95, 2, Limit, None, Some(1000)),
        )
        .unwrap();
    let observation = rooms
        .participant_observation("perp-expiry", "V-BTC-PERP", 20)
        .unwrap();
    let Some(crate::AccountSnapshot::Perp(account)) = observation.own_account else {
        panic!()
    };
    assert!(account.reserved_margin > 0);
    rooms.advance_clock("perp-expiry", 1).unwrap();
    let observation = rooms
        .participant_observation("perp-expiry", "V-BTC-PERP", 20)
        .unwrap();
    let Some(crate::AccountSnapshot::Perp(account)) = observation.own_account else {
        panic!()
    };
    assert_eq!(account.reserved_margin, 0);
    assert!(observation.own_orders.is_empty());
}

#[test]
fn protection_unbounded_reduce_only_sweeps_but_cannot_reverse_the_position() {
    use crate::TradingApi;
    let mut scenario = pending_perp_liquidation_scenario("unbounded-reduce");
    scenario.seed_orders = vec![
        limit(1, 10, Side::Sell, 100, 2),
        limit(2, 20, Side::Buy, 100, 2),
        limit(3, 30, Side::Buy, 98, 1),
        limit(4, 30, Side::Buy, 95, 1),
    ];
    let mut rooms = RoomManager::new();
    rooms.create_room(scenario).unwrap();
    let close = |rooms: &mut RoomManager, id, qty| {
        crate::OrderGateway::new(rooms, id)
            .submit_action(crate::GatewayRequest {
                participant_id: "sweeper".into(),
                room_id: "unbounded-reduce".into(),
                instrument_id: None,
                account_id: 20,
                action: crate::OrderAction::PlaceUnboundedMarket {
                    position_side: Default::default(),
                    side: Side::Sell,
                    qty,
                    reduce_only: true,
                    valid_until_market_time_ms: Some(5000),
                },
            })
            .unwrap()
            .execution
    };
    let too_large = close(&mut rooms, 5, 3);
    let ActorExecutionResult::Accepted(MarketExecution::Perp(too_large)) = too_large.result else {
        panic!()
    };
    assert!(too_large.events.iter().any(|event| matches!(
        event.event,
        Event::RiskRejected {
            reason: crate::model::RiskRejectReason::ReduceOnlyExceedsPosition,
            ..
        }
    )));
    let sweep = close(&mut rooms, 6, 2);
    let ActorExecutionResult::Accepted(MarketExecution::Perp(sweep)) = sweep.result else {
        panic!()
    };
    assert_eq!(
        sweep
            .events
            .iter()
            .filter_map(|event| match &event.event {
                Event::TradePrinted(trade) => Some(trade.price_tick),
                _ => None,
            })
            .collect::<Vec<_>>(),
        vec![98, 95]
    );
    let observation = rooms
        .participant_observation("unbounded-reduce", "V-BTC-PERP", 20)
        .unwrap();
    let Some(crate::AccountSnapshot::Perp(account)) = observation.own_account else {
        panic!()
    };
    assert_eq!(account.position_qty, 0);
    let flat = close(&mut rooms, 7, 1);
    let ActorExecutionResult::Accepted(MarketExecution::Perp(flat)) = flat.result else {
        panic!()
    };
    assert!(flat.events.iter().any(|event| matches!(
        event.event,
        Event::RiskRejected {
            reason: crate::model::RiskRejectReason::ReduceOnlyWouldIncreasePosition,
            ..
        }
    )));
}

#[test]
fn conditional_order_scan_matches_the_reference_scan() {
    // Mark moves (no perp event), trades at random prices, and armed, replaced
    // and cancelled entries on both triggers; each step compares the scan with
    // the reference on copies of the venue, before and after the room's pass.
    let room = "conditional-scan";
    let mut rooms = RoomManager::new();
    rooms
        .create_room(pending_perp_liquidation_scenario(room))
        .unwrap();
    let mut seed = 0x9E37_79B9_7F4A_7C15u64;
    let mut next = move |n: u64| {
        seed ^= seed << 13;
        seed ^= seed >> 7;
        seed ^= seed << 17;
        seed % n
    };
    let mut order_id = 1_000;
    let mut triggered = 0;
    for step in 0..1_000 {
        let simulation = rooms.simulation_room(room).unwrap();
        let venue = simulation.venue_id_for_instrument("V-BTC-PERP").unwrap();
        let mut fast = simulation.exchange(&venue).unwrap().clone();
        let mut reference = fast.clone();
        let a = fast.prepare_conditional_orders();
        let b = reference.prepare_conditional_orders_reference();
        assert_eq!(a, b, "step {step}");
        // The scan writes only conditional orders, which read with their
        // cursors; the whole venue (with its growing log) is compared now and then.
        let exact = |actor: &ExchangeActor| {
            actor
                .all_conditional_orders()
                .map(|(p, cursor)| (p.clone(), cursor))
                .map(|(mut p, cursor)| {
                    p.last_checked_event_seq = cursor;
                    p
                })
                .collect::<Vec<_>>()
        };
        assert_eq!(exact(&fast), exact(&reference), "step {step}");
        if step % 100 == 0 {
            assert_eq!(
                serde_json::to_value(&fast).unwrap(),
                serde_json::to_value(&reference).unwrap(),
                "step {step}"
            );
        }
        triggered += a.len();
        let price = 90 + next(21) as i64;
        let command = match next(6) {
            0 => Command::SetMarkPrice(SetMarkPrice { price_tick: price }),
            1 | 2 => Command::SetConditionalOrder {
                account_id: [10, 20, 30][next(3) as usize],
                key: format!("k{}", next(8)),
                spec: (next(5) != 0).then(|| {
                    Box::new(crate::conditional_orders::ConditionalOrderSpec {
                        side: if next(2) == 0 { Side::Buy } else { Side::Sell },
                        position_side: crate::PositionSide::Both,
                        qty: 1,
                        trigger_price_tick: price,
                        above: next(2) == 0,
                        trigger: if next(2) == 0 {
                            crate::ProtectionTrigger::Last
                        } else {
                            crate::ProtectionTrigger::Mark
                        },
                        limit_price_tick: (next(2) == 0).then_some(price),
                        protection: None,
                    })
                }),
            },
            _ => {
                order_id += 1;
                let (side, account) = if next(2) == 0 { (Side::Sell, 10) } else { (Side::Buy, 30) };
                Command::NewOrder(NewOrder {
                    position_side: crate::model::PositionSide::Both,
                    order_id,
                    account_id: account,
                    side,
                    qty: 1 + next(3),
                    reduce_only: false,
                    kind: OrderKind::Limit { price_tick: price },
                })
            }
        };
        // Half the steps skip the room's own pass, so the next comparison
        // sees new events after the cursors as well as none.
        if next(2) == 0 {
            rooms
                .apply_to_instrument(room, "V-BTC-PERP", command)
                .unwrap();
        } else {
            rooms
                .simulation_room_mut(room)
                .unwrap()
                .apply_to_instrument("V-BTC-PERP", command)
                .unwrap();
        }
    }
    assert!(triggered > 20, "only {triggered} entries triggered");
}

#[test]
fn conditional_orders_match_eager_cursors_in_lockstep() {
    // Two rooms take the same commands; one runs the reference pass, which
    // checks every armed entry from its own cursor and rewrites the cursor.
    // Each step the triggered entries, every account's conditional orders,
    // the command results and (now and then) the venue JSON must match, a
    // pass must change the entries exactly when the reference writes one,
    // and a venue restored from its JSON must run the same pass.
    use crate::actor::CONDITIONAL_REFERENCE;
    let room = "conditional-lockstep";
    let mut lazy = RoomManager::new();
    let mut eager = RoomManager::new();
    for rooms in [&mut lazy, &mut eager] {
        rooms
            .create_room(pending_perp_liquidation_scenario(room))
            .unwrap();
    }
    let venue = |rooms: &RoomManager| {
        let simulation = rooms.simulation_room(room).unwrap();
        let venue = simulation.venue_id_for_instrument("V-BTC-PERP").unwrap();
        simulation.exchange(&venue).unwrap().clone()
    };
    let orders = |actor: &ExchangeActor| {
        [10, 20, 30]
            .map(|account| actor.conditional_orders("V-BTC-PERP", account))
            .concat()
    };
    let mut seed = 0x6A09_E667_F3BC_C908u64;
    let mut next = move |n: u64| {
        seed ^= seed << 13;
        seed ^= seed >> 7;
        seed ^= seed << 17;
        seed % n
    };
    let mut order_id = 1_000;
    let (mut triggered, mut moved, mut still, mut submitted) = (0, 0, 0, 0);
    for step in 0..1_500 {
        let (a, b) = (venue(&lazy), venue(&eager));
        assert_eq!(orders(&a), orders(&b), "step {step}");
        let (mut fa, mut fb) = (a.clone(), b.clone());
        let ra = fa.prepare_conditional_orders();
        CONDITIONAL_REFERENCE.set(true);
        let rb = fb.prepare_conditional_orders();
        CONDITIONAL_REFERENCE.set(false);
        assert_eq!(ra, rb, "step {step}");
        assert_eq!(orders(&fa), orders(&fb), "step {step}");
        let changed = !fa.conditional_orders_unchanged(&a);
        assert_eq!(changed, !fb.conditional_orders_unchanged(&b), "step {step}");
        triggered += ra.len();
        match (changed, ra.is_empty()) {
            (true, true) => moved += 1,
            (false, _) => still += 1,
            _ => {}
        }
        if step % 50 == 0 {
            let json = serde_json::to_value(&a).unwrap();
            assert_eq!(json, serde_json::to_value(&b).unwrap(), "step {step}");
            let mut restored: ExchangeActor = serde_json::from_value(json.clone()).unwrap();
            assert_eq!(serde_json::to_value(&restored).unwrap(), json, "step {step}");
            assert_eq!(restored.prepare_conditional_orders(), ra, "step {step}");
            assert_eq!(orders(&restored), orders(&fa), "step {step}");
        }
        let price = 90 + next(21) as i64;
        let command = match next(7) {
            0 => Command::SetMarkPrice(SetMarkPrice { price_tick: price }),
            1..=3 => Command::SetConditionalOrder {
                account_id: [10, 20, 30][next(3) as usize],
                key: format!("k{}", next(8)),
                spec: (next(6) != 0).then(|| {
                    Box::new(crate::conditional_orders::ConditionalOrderSpec {
                        side: if next(2) == 0 { Side::Buy } else { Side::Sell },
                        position_side: crate::PositionSide::Both,
                        qty: 1,
                        trigger_price_tick: price + next(9) as i64 - 4,
                        above: next(2) == 0,
                        trigger: if next(2) == 0 {
                            crate::ProtectionTrigger::Last
                        } else {
                            crate::ProtectionTrigger::Mark
                        },
                        limit_price_tick: (next(2) == 0).then_some(price),
                        protection: None,
                    })
                }),
            },
            _ => {
                order_id += 1;
                let (side, account) = if next(2) == 0 { (Side::Sell, 10) } else { (Side::Buy, 30) };
                Command::NewOrder(NewOrder {
                    position_side: crate::model::PositionSide::Both,
                    order_id,
                    account_id: account,
                    side,
                    qty: 1 + next(3),
                    reduce_only: false,
                    kind: OrderKind::Limit { price_tick: price },
                })
            }
        };
        // Half the steps skip the room's own pass (and the orders it submits).
        let pass = next(2) == 0;
        let mut results = Vec::new();
        for (rooms, reference) in [(&mut lazy, false), (&mut eager, true)] {
            CONDITIONAL_REFERENCE.set(reference);
            let result = if pass {
                format!("{:?}", rooms.apply_to_instrument(room, "V-BTC-PERP", command.clone()))
            } else {
                format!(
                    "{:?}",
                    rooms
                        .simulation_room_mut(room)
                        .unwrap()
                        .apply_to_instrument("V-BTC-PERP", command.clone())
                )
            };
            CONDITIONAL_REFERENCE.set(false);
            results.push(result);
        }
        assert_eq!(results[0], results[1], "step {step}");
        submitted += orders(&venue(&lazy))
            .iter()
            .filter(|o| o.submitted_order_id.is_some())
            .count();
    }
    assert!(
        triggered > 20 && moved > 50 && still > 50 && submitted > 20,
        "triggered {triggered}, moved {moved}, still {still}, submitted {submitted}"
    );
}

#[test]
fn position_exit_scans_match_the_reference_scans() {
    // Two accounts trade into, out of and across positions and set
    // take-profit, stop, trailing and partial exits on both triggers while the
    // mark and the last trade move. Each step compares both passes with their
    // references on copies of the venue, before and after the room's own pass.
    let room = "exit-scan";
    let mut rooms = RoomManager::new();
    rooms
        .create_room(pending_perp_liquidation_scenario(room))
        .unwrap();
    let mut seed = 0x2545_F491_4F6C_DD1Du64;
    let mut next = move |n: u64| {
        seed ^= seed << 13;
        seed ^= seed >> 7;
        seed ^= seed << 17;
        seed % n
    };
    let mut order_id = 1_000;
    let (mut exits, mut armed, mut completed) = (0, 0, 0);
    for step in 0..1_000 {
        let simulation = rooms.simulation_room(room).unwrap();
        let venue = simulation.venue_id_for_instrument("V-BTC-PERP").unwrap();
        let actor = simulation.exchange(&venue).unwrap();
        armed += actor
            .all_position_protections()
            .filter(|p| p.status == "armed")
            .count();
        let (mut fast, mut reference) = (actor.clone(), actor.clone());
        let a = fast.prepare_position_exits();
        let b = reference.prepare_position_exits_reference();
        assert_eq!(a, b, "step {step}");
        assert_eq!(
            fast.all_position_protections().collect::<Vec<_>>(),
            reference.all_position_protections().collect::<Vec<_>>(),
            "step {step}"
        );
        exits += a.len();
        let (mut fast, mut reference) = (actor.clone(), actor.clone());
        fast.complete_flat_position_protections();
        reference.complete_flat_position_protections_reference();
        let done = |a: &crate::ExchangeActor| {
            a.all_position_protections()
                .filter(|p| p.status == "completed")
                .count()
        };
        completed += done(&reference) - done(actor);
        assert_eq!(
            fast.all_position_protections().collect::<Vec<_>>(),
            reference.all_position_protections().collect::<Vec<_>>(),
            "step {step}"
        );
        if step % 100 == 0 {
            assert_eq!(
                serde_json::to_value(&fast).unwrap(),
                serde_json::to_value(&reference).unwrap(),
                "step {step}"
            );
        }
        let price = 92 + next(17) as i64;
        let account = if next(2) == 0 { 10 } else { 30 };
        // Either direction, so positions cross zero.
        let long = next(2) == 0;
        let command = match next(7) {
            0 => Command::SetMarkPrice(SetMarkPrice { price_tick: price }),
            1 | 2 => {
                let distance = 1 + next(6) as i64;
                Command::SetPositionProtection {
                    account_id: account,
                    position_side: crate::PositionSide::Both,
                    protection: (next(6) != 0).then(|| {
                        Box::new(crate::PositionProtectionSpec {
                            take_profit_tick: (next(2) == 0)
                                .then_some(if long { 100 + distance } else { 100 - distance }),
                            stop_loss_tick: (next(2) == 0)
                                .then_some(if long { 100 - distance } else { 100 + distance }),
                            trigger: if next(2) == 0 {
                                crate::ProtectionTrigger::Last
                            } else {
                                crate::ProtectionTrigger::Mark
                            },
                            trailing_distance_tick: (next(3) == 0).then_some(distance),
                            exit_price_tick: None,
                            exit_qty: (next(3) == 0).then_some(1),
                            take_profit_steps: vec![],
                        })
                    }),
                }
            }
            _ => {
                order_id += 1;
                Command::NewOrder(NewOrder {
                    position_side: crate::model::PositionSide::Both,
                    order_id,
                    account_id: account,
                    side: if long { Side::Buy } else { Side::Sell },
                    qty: 1 + next(3),
                    reduce_only: false,
                    kind: OrderKind::Limit { price_tick: price },
                })
            }
        };
        // Half the steps skip the room's own pass, so the next comparison
        // sees moved prices and positions as well as settled ones.
        if next(2) == 0 {
            rooms
                .apply_to_instrument(room, "V-BTC-PERP", command)
                .unwrap();
        } else {
            rooms
                .simulation_room_mut(room)
                .unwrap()
                .apply_to_instrument("V-BTC-PERP", command)
                .unwrap();
        }
    }
    assert!(
        exits > 20 && armed > 200 && completed > 5,
        "exits {exits}, armed {armed}, completed {completed}"
    );
}
