use std::{
    collections::{BTreeMap, BTreeSet},
    sync::Arc,
};

use serde::{Deserialize, Serialize};

use crate::{
    account::{ClearingError, Money, VenueAccountSnapshot},
    actor::{
        AccountSnapshot, AccountSnapshots, ActorExecution, ActorRejectReason, ActorSeq,
        ExchangeActor, MarketStatus, RoomId,
    },
    clock::SimulationClock,
    market::{
        ExchangeConfig, MarketConfig, MarketConfigError, MarketKind, VenueAssetPolicyConfig,
        VenueId,
    },
    model::{AccountId, BookSnapshot, Command, OrderId},
    portfolio::{PortfolioAccountSnapshot, PortfolioStore},
    scenario::{
        ScenarioAccount, ScenarioConfig, ScenarioError, ScenarioPortfolio, ScenarioSeedOrder,
    },
    transfer::{VenueTransfer, VenueTransferKind, VenueTransferRejectReason, VenueTransferStatus},
    venue_rules::VenueRuleConfig,
};

pub type UserId = String;

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct WalletBalance {
    pub total: String,
    pub reserved: String,
    pub available: String,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct WalletTransferEvent {
    pub wallet_seq: u64,
    pub market_time_ms: u64,
    pub account_id: AccountId,
    pub venue_id: String,
    pub asset_id: String,
    pub transfer_id: u64,
    pub kind: VenueTransferKind,
    pub status: VenueTransferStatus,
    pub amount: String,
    pub reject_reason: Option<String>,
    pub venue_balance: Option<WalletBalance>,
    pub portfolio_balance: Option<WalletBalance>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub margin_updates: Vec<crate::actor::ExecutionMarginUpdate>,
}

#[cfg(test)]
thread_local! {
    pub(crate) static SNAPSHOT_LIQUIDATION_REFERENCE: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct SimulationRoom {
    #[serde(default, skip_serializing_if = "crate::history::History::is_empty")]
    wallet_events: crate::history::History<WalletTransferEvent>,
    room_id: RoomId,
    primary_venue_id: VenueId,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    market_events: Vec<crate::market_events::MarketEvent>,
    exchanges: BTreeMap<VenueId, Arc<ExchangeActor>>,
    portfolios: PortfolioStore,
    #[serde(default)]
    user_accounts: crate::shared_map::SharedMap<UserId, BTreeSet<AccountId>>,
    #[serde(default)]
    asset_ledger: crate::history::History<AssetLedgerEntry>,
    #[serde(default)]
    next_asset_ledger_seq: u64,
    #[serde(default)]
    pending_venue_transfers: Vec<PendingVenueTransfer>,
    #[serde(default)]
    next_command_seq: ActorSeq,
    #[serde(skip)]
    pending_clock_executions: Vec<ActorExecution>,
}

impl SimulationRoom {
    pub(crate) fn compact_archived_history(&mut self) {
        for exchange in self.exchanges.values_mut() {
            Arc::make_mut(exchange).compact_archived_history();
        }
    }
    /// Transfers have their own durable cursor; they are not matching commands.
    pub fn wallet_event_count(&self) -> usize {
        self.wallet_events.len()
    }

    pub fn wallet_events_from(&self, start: usize) -> impl Iterator<Item = &WalletTransferEvent> {
        self.wallet_events.iter_from(start)
    }

    fn record_wallet_transfer(&mut self, venue_id: &str, transfer: &VenueTransfer) {
        let exchange = &self.exchanges[venue_id];
        let venue = exchange.venue_balance_snapshot(transfer.account_id, &transfer.asset_id);
        let portfolio = self
            .portfolios
            .balance_snapshot(transfer.account_id, &transfer.asset_id);
        self.wallet_events.push(WalletTransferEvent {
            wallet_seq: self.wallet_events.len() as u64,
            market_time_ms: exchange.clock().market_time_ms(),
            account_id: transfer.account_id,
            venue_id: venue_id.into(),
            asset_id: transfer.asset_id.clone(),
            transfer_id: transfer.transfer_id,
            kind: transfer.kind,
            status: transfer.status,
            amount: transfer.amount.to_string(),
            reject_reason: transfer.reject_reason.as_ref().map(|r| format!("{r:?}")),
            venue_balance: venue.map(|v| WalletBalance {
                total: v.total.to_string(),
                reserved: v.reserved.to_string(),
                available: v.available.to_string(),
            }),
            margin_updates: exchange
                .instrument_ids()
                .into_iter()
                .filter_map(|id| {
                    match exchange
                        .account_snapshot_for(id, transfer.account_id)
                        .ok()
                        .flatten()?
                    {
                        AccountSnapshot::Perp(account) => {
                            Some(crate::actor::ExecutionMarginUpdate {
                                instrument_id: id.into(),
                                account,
                            })
                        }
                        _ => None,
                    }
                })
                .collect(),
            portfolio_balance: portfolio.map(|v| WalletBalance {
                total: v.total.to_string(),
                reserved: v.reserved.to_string(),
                available: v.available.to_string(),
            }),
        });
    }
    pub fn from_scenario(scenario: ScenarioConfig) -> Result<SimulationBootstrap, ScenarioError> {
        let instruments = std::iter::once(&scenario.market)
            .chain(scenario.extra_markets.iter())
            .map(|m| m.instrument_id().to_string())
            .collect::<Vec<_>>();
        crate::market_events::validate_events(&scenario.market_events, &instruments)
            .map_err(ScenarioError::InvalidMarketEvents)?;
        let room_id = scenario.room_id.clone();
        let primary_venue_id = scenario.market.venue_id().to_string();
        let mut markets_by_venue = BTreeMap::<VenueId, Vec<MarketConfig>>::new();
        markets_by_venue
            .entry(primary_venue_id.clone())
            .or_default()
            .push(scenario.market.clone());
        for market in &scenario.extra_markets {
            markets_by_venue
                .entry(market.venue_id().to_string())
                .or_default()
                .push(market.clone());
        }

        let mut exchanges = BTreeMap::new();
        for (venue_id, markets) in markets_by_venue {
            let mut config = ExchangeConfig::new(venue_id.clone(), markets)
                .map_err(ScenarioError::MarketConfig)?;
            config.merge_asset_metadata(&scenario.assets);
            config.venue_rules = rules_for_exchange(&scenario, &config)?;
            config.asset_policy = asset_policy_for_exchange(&scenario, &config);
            let mut exchange =
                ExchangeActor::new(room_id.clone(), config).map_err(ScenarioError::MarketConfig)?;
            for account in &scenario.accounts {
                apply_account_to_exchange(account, &mut exchange)?;
            }
            exchanges.insert(venue_id, Arc::new(exchange));
        }

        let mut room = Self {
            room_id: room_id.clone(),
            primary_venue_id,
            market_events: scenario.market_events.clone(),
            exchanges,
            portfolios: PortfolioStore::new(),
            user_accounts: scenario_user_accounts(&scenario).into(),
            asset_ledger: crate::history::History::default(),
            next_asset_ledger_seq: 0,
            pending_venue_transfers: Vec::new(),
            next_command_seq: 0,
            pending_clock_executions: Vec::new(),
            wallet_events: crate::history::History::default(),
        };

        for portfolio in &scenario.initial_portfolios {
            room.apply_initial_portfolio(portfolio);
        }
        for allocation in &scenario.initial_allocations {
            let venue_id = room.primary_venue_id.clone();
            room.apply_initial_allocation(
                &venue_id,
                allocation.account_id,
                allocation.asset_id.clone(),
                allocation.amount,
            )?;
        }
        for allocation in &scenario.routed_initial_allocations {
            room.apply_initial_allocation(
                &allocation.venue_id,
                allocation.account_id,
                allocation.asset_id.clone(),
                allocation.amount,
            )?;
        }

        let mut seed_executions = Vec::with_capacity(scenario.seed_order_count());
        for command in scenario.seed_orders {
            seed_executions.push(room.apply(command));
        }
        for seed_order in scenario.routed_seed_orders {
            seed_executions.push(room.apply_seed_order(seed_order)?);
        }

        Ok(SimulationBootstrap {
            room,
            seed_executions,
        })
    }

    pub fn from_exchange(exchange: ExchangeActor) -> Self {
        let room_id = exchange.room_id().to_string();
        let primary_venue_id = exchange.venue_id().to_string();
        let portfolios = exchange.portfolio_store().clone();
        let next_command_seq = exchange.next_command_seq();
        let mut exchanges = BTreeMap::new();
        exchanges.insert(primary_venue_id.clone(), Arc::new(exchange));
        Self {
            room_id,
            primary_venue_id,
            market_events: Vec::new(),
            exchanges,
            portfolios,
            user_accounts: crate::shared_map::SharedMap::default(),
            asset_ledger: crate::history::History::default(),
            next_asset_ledger_seq: 0,
            pending_venue_transfers: Vec::new(),
            next_command_seq,
            pending_clock_executions: Vec::new(),
            wallet_events: crate::history::History::default(),
        }
    }

    pub fn visible_market_events(
        &self,
        instrument: &str,
    ) -> Vec<crate::market_events::MarketEvent> {
        self.market_events
            .iter()
            .filter(|e| {
                e.instrument_id == instrument && e.published_at_ms <= self.clock().market_time_ms()
            })
            .cloned()
            .collect()
    }

    pub fn validate_market_events(&self) -> Result<(), String> {
        crate::market_events::validate_events(&self.market_events, &self.instrument_ids())
    }

    pub fn room_id(&self) -> &str {
        &self.room_id
    }

    pub fn primary_venue_id(&self) -> &str {
        &self.primary_venue_id
    }

    pub fn next_command_seq(&self) -> ActorSeq {
        self.next_command_seq
    }

    pub(crate) fn fork_order_venue(&mut self, instrument: &str) -> bool {
        if self.exchanges.values().any(|e| e.has_order_automation()) {
            return false;
        }
        let Some(venue) = self.venue_id_for_instrument(instrument) else {
            return false;
        };
        self.exchanges.retain(|id, _| *id == venue);
        self.primary_venue_id = venue;
        true
    }

    pub(crate) fn merge_order_venue(
        &mut self,
        predecessor: &Self,
        mut candidate: Self,
        execution: &mut ActorExecution,
    ) -> Result<bool, ActorRejectReason> {
        let venue = &candidate.primary_venue_id;
        let (Some(current), Some(expected)) =
            (self.exchanges.get(venue), predecessor.exchanges.get(venue))
        else {
            return Ok(false);
        };
        if candidate.exchanges.len() != 1 || !Arc::ptr_eq(current, expected) {
            return Ok(false);
        }
        let next = self
            .next_command_seq
            .checked_add(1)
            .ok_or(ActorRejectReason::Clearing(ClearingError::BalanceOverflow))?;
        execution.command_seq = self.next_command_seq;
        self.next_command_seq = next;
        self.exchanges
            .insert(venue.clone(), candidate.exchanges.remove(venue).unwrap());
        Ok(true)
    }

    pub fn venue_ids(&self) -> Vec<&str> {
        self.exchanges.keys().map(String::as_str).collect()
    }

    pub fn instrument_ids(&self) -> Vec<String> {
        self.exchanges
            .values()
            .flat_map(|exchange| exchange.instrument_ids().into_iter().map(str::to_string))
            .collect()
    }

    pub fn primary_exchange(&self) -> &ExchangeActor {
        self.exchanges
            .get(&self.primary_venue_id)
            .expect("simulation room must have a primary exchange")
    }

    pub fn primary_exchange_mut(&mut self) -> &mut ExchangeActor {
        Arc::make_mut(
            self.exchanges
                .get_mut(&self.primary_venue_id)
                .expect("simulation room must have a primary exchange"),
        )
    }

    pub fn exchange(&self, venue_id: &str) -> Result<&ExchangeActor, SimulationRoomError> {
        self.exchanges
            .get(venue_id)
            .map(Arc::as_ref)
            .ok_or_else(|| SimulationRoomError::VenueNotFound {
                venue_id: venue_id.to_string(),
            })
    }

    pub fn status(&self) -> MarketStatus {
        self.primary_exchange().status()
    }

    pub fn pause(&mut self) {
        for exchange in self.exchanges.values_mut() {
            let exchange = Arc::make_mut(exchange);
            exchange.pause();
        }
    }

    pub fn resume(&mut self) {
        for exchange in self.exchanges.values_mut() {
            let exchange = Arc::make_mut(exchange);
            exchange.resume();
        }
    }

    pub fn close(&mut self) {
        for exchange in self.exchanges.values_mut() {
            let exchange = Arc::make_mut(exchange);
            exchange.close();
        }
    }

    pub fn restore_status(&mut self, status: MarketStatus) {
        for exchange in self.exchanges.values_mut() {
            let exchange = Arc::make_mut(exchange);
            exchange.restore_status(status);
        }
    }

    pub fn apply(&mut self, command: Command) -> ActorExecution {
        let command_seq = self.take_command_seq();
        let mut execution = self.primary_exchange_mut().apply(command);
        execution.command_seq = command_seq;
        execution
    }

    pub fn position_protections(
        &self,
        instrument: &str,
        account: AccountId,
    ) -> Vec<crate::PositionProtection> {
        self.instrument_exchange(instrument)
            .map(|e| e.position_protections(instrument, account))
            .unwrap_or_default()
    }
    pub fn has_active_position_protections(&self) -> bool {
        self.exchanges
            .values()
            .any(|e| e.has_active_position_protections())
    }

    pub fn complete_flat_position_protections(&mut self) {
        for exchange in self
            .exchanges
            .values_mut()
            .filter(|e| e.has_order_automation())
        {
            let exchange = Arc::make_mut(exchange);
            exchange.complete_flat_position_protections();
        }
    }

    pub fn prepare_position_exits(
        &mut self,
    ) -> Vec<crate::position_protection::PositionExitRequest> {
        self.exchanges
            .values_mut()
            .filter(|e| e.has_order_automation())
            .flat_map(|e| Arc::make_mut(e).prepare_position_exits())
            .collect()
    }
    pub fn prepare_conditional_orders(
        &mut self,
    ) -> Vec<crate::conditional_orders::ConditionalOrder> {
        self.exchanges
            .values_mut()
            .filter(|e| e.has_order_automation())
            .flat_map(|e| Arc::make_mut(e).prepare_conditional_orders())
            .collect()
    }
    pub fn record_conditional_order(
        &mut self,
        p: &crate::conditional_orders::ConditionalOrder,
        id: u64,
        accepted: bool,
    ) {
        if let Some(venue) = self.venue_id_for_instrument(&p.instrument_id) {
            self.exchanges
                .get_mut(&venue)
                .map(Arc::make_mut)
                .unwrap()
                .record_conditional_order(p, id, accepted);
        }
    }
    pub fn record_position_exit(
        &mut self,
        instrument: &str,
        account: AccountId,
        side: crate::PositionSide,
        order_id: u64,
    ) {
        if let Some(venue) = self.venue_id_for_instrument(instrument) {
            self.exchanges
                .get_mut(&venue)
                .map(Arc::make_mut)
                .unwrap()
                .record_position_exit(instrument, account, side, order_id);
        }
    }
    pub fn apply_to_instrument(
        &mut self,
        instrument_id: &str,
        command: Command,
    ) -> Result<ActorExecution, ActorRejectReason> {
        self.apply_to_instrument_from(
            instrument_id,
            command,
            crate::actor::CommandOrigin::External,
        )
    }

    pub fn apply_to_instrument_from(
        &mut self,
        instrument_id: &str,
        command: Command,
        origin: crate::actor::CommandOrigin,
    ) -> Result<ActorExecution, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?;
        let command_seq = self.take_command_seq();
        let mut execution = self
            .exchanges
            .values_mut()
            .find(|exchange| exchange.has_instrument(instrument_id))
            .map(Arc::make_mut)
            .expect("venue was resolved from exchanges")
            .apply_to_instrument_from(instrument_id, command, origin)?;
        execution.command_seq = command_seq;
        Ok(execution)
    }

    pub fn liquidate_account(
        &mut self,
        instrument_id: &str,
        account_id: AccountId,
        order_id: OrderId,
    ) -> Result<ActorExecution, ActorRejectReason> {
        let venue_id = self.venue_id_for_instrument(instrument_id).ok_or_else(|| {
            ActorRejectReason::InstrumentNotFound {
                instrument_id: instrument_id.to_string(),
            }
        })?;
        let command_seq = self.take_command_seq();
        let mut execution = self
            .exchanges
            .get_mut(&venue_id)
            .map(Arc::make_mut)
            .expect("venue id was resolved from exchanges")
            .liquidate_account(instrument_id, account_id, order_id)?;
        execution.command_seq = command_seq;
        Ok(execution)
    }

    pub fn book_snapshot(&self) -> BookSnapshot {
        self.primary_exchange().book_snapshot()
    }

    pub fn perp_price_snapshot(
        &self,
        instrument_id: &str,
    ) -> Result<Option<crate::PerpPriceSnapshot>, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?
            .perp_price_snapshot(instrument_id)
    }

    pub fn book_snapshot_for(
        &self,
        instrument_id: &str,
    ) -> Result<BookSnapshot, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?
            .book_snapshot_for(instrument_id)
    }

    pub fn account_snapshot(&self, account_id: AccountId) -> Option<AccountSnapshot> {
        self.primary_exchange().account_snapshot(account_id)
    }

    pub fn account_snapshot_for(
        &self,
        instrument_id: &str,
        account_id: AccountId,
    ) -> Result<Option<AccountSnapshot>, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?
            .account_snapshot_for(instrument_id, account_id)
    }

    pub fn account_snapshots(&self) -> AccountSnapshots {
        self.primary_exchange().account_snapshots()
    }

    pub fn account_snapshots_for(
        &self,
        instrument_id: &str,
    ) -> Result<AccountSnapshots, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?
            .account_snapshots_for(instrument_id)
    }

    pub fn pending_liquidation_accounts_for(
        &self,
        instrument_id: &str,
    ) -> Result<Vec<AccountId>, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?
            .pending_liquidation_accounts_for(instrument_id)
    }

    pub(crate) fn liquidatable_account_ids_for(
        &self,
        instrument_id: &str,
    ) -> Result<Vec<AccountId>, ActorRejectReason> {
        #[cfg(test)]
        if SNAPSHOT_LIQUIDATION_REFERENCE.get() {
            return Ok(match self.account_snapshots_for(instrument_id)? {
                AccountSnapshots::Spot(_) => Vec::new(),
                AccountSnapshots::Perp(accounts) => accounts
                    .into_iter()
                    .filter(|account| {
                        account.has_open_position()
                            && account.margin_status == crate::PerpMarginStatus::Liquidatable
                    })
                    .map(|account| account.account_id)
                    .collect(),
            });
        }
        self.instrument_exchange(instrument_id)?
            .liquidatable_account_ids_for(instrument_id)
    }

    pub(crate) fn liquidation_candidate_is_active_for(
        &self,
        instrument_id: &str,
        account_id: AccountId,
    ) -> Result<bool, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?
            .liquidation_candidate_is_active_for(instrument_id, account_id)
    }

    pub fn cross_margin_collateral_orders_for_liquidation(
        &self,
        instrument_id: &str,
        account_id: AccountId,
    ) -> Result<Vec<(String, OrderId)>, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?
            .cross_margin_collateral_orders_for_liquidation(instrument_id, account_id)
    }

    pub fn order_owner_for(
        &self,
        instrument_id: &str,
        order_id: OrderId,
    ) -> Result<Option<AccountId>, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?
            .order_owner_for(instrument_id, order_id)
    }

    pub fn resting_orders_for_account(
        &self,
        instrument_id: &str,
        account_id: AccountId,
    ) -> Result<Vec<crate::model::Order>, ActorRejectReason> {
        self.instrument_exchange(instrument_id)?
            .resting_orders_for_account(instrument_id, account_id)
    }

    pub fn venue_account_snapshot(&self, account_id: AccountId) -> VenueAccountSnapshot {
        self.primary_exchange().venue_account_snapshot(account_id)
    }

    pub fn venue_account_snapshots(&self) -> Vec<VenueAccountSnapshot> {
        self.primary_exchange().venue_account_snapshots()
    }

    pub fn venue_account_snapshots_by_venue(&self) -> Vec<VenueAccountVenueSnapshot> {
        self.exchanges
            .iter()
            .flat_map(|(venue_id, exchange)| {
                exchange
                    .venue_account_snapshots()
                    .into_iter()
                    .map(|account| VenueAccountVenueSnapshot {
                        venue_id: venue_id.clone(),
                        account,
                    })
                    .collect::<Vec<_>>()
            })
            .collect()
    }

    pub fn portfolio_snapshot(&self, account_id: AccountId) -> PortfolioAccountSnapshot {
        self.portfolios.account_snapshot(account_id)
    }

    pub fn portfolio_snapshots(&self) -> Vec<PortfolioAccountSnapshot> {
        self.portfolios.account_snapshots()
    }

    pub fn clock(&self) -> SimulationClock {
        self.primary_exchange().clock()
    }

    pub(crate) fn has_funding(&self) -> bool {
        self.exchanges.values().any(|exchange| {
            exchange
                .config()
                .markets
                .iter()
                .any(|market| matches!(market, MarketConfig::Perp(perp) if perp.funding.is_some()))
        })
    }

    pub fn advance_clock(&mut self, steps: u64) -> Result<Vec<VenueTransfer>, SimulationRoomError> {
        self.clock()
            .checked_time_after(steps)
            .map_err(SimulationRoomError::Clock)?;
        let mut staged = self.clone();
        let completed = staged.advance_clock_inner(steps)?;
        *self = staged;
        Ok(completed)
    }

    pub(crate) fn take_clock_executions(&mut self) -> Vec<ActorExecution> {
        std::mem::take(&mut self.pending_clock_executions)
    }

    fn advance_clock_inner(
        &mut self,
        steps: u64,
    ) -> Result<Vec<VenueTransfer>, SimulationRoomError> {
        let mut completed = Vec::new();
        let venue_ids = self.exchanges.keys().cloned().collect::<Vec<_>>();
        for _ in 0..steps {
            // Advance every venue to the same global step before applying any
            // cross-venue transfer links. Otherwise a deposit created by a
            // completed withdrawal could be advanced again in this same step
            // solely because its destination sorts after its source.
            let mut due_by_venue = Vec::with_capacity(venue_ids.len());
            for venue_id in &venue_ids {
                let exchange = self
                    .exchanges
                    .get_mut(venue_id)
                    .map(Arc::make_mut)
                    .expect("venue id was collected from exchanges");
                let due = exchange
                    .advance_clock_venue_only(1)
                    .map_err(SimulationRoomError::Clearing)?;
                let funding = exchange.take_clock_executions();
                due_by_venue.push((venue_id.clone(), due));
                for mut execution in funding {
                    execution.command_seq = self.take_command_seq();
                    self.pending_clock_executions.push(execution);
                }
            }

            // Make all venue completions visible before creating the linked
            // deposits for this step. Linked deposits therefore begin at the
            // synchronized destination clock and cannot complete until a
            // later global step when their configured delay is non-zero.
            for (venue_id, due) in &due_by_venue {
                for transfer in due {
                    self.apply_portfolio_effect_for_finished_transfer(venue_id, transfer);
                    self.record_wallet_transfer(venue_id, transfer);
                }
                completed.extend(due.iter().cloned());
            }
            for (venue_id, due) in due_by_venue {
                completed.extend(self.process_completed_venue_transfer_links(&venue_id, &due)?);
            }
        }
        Ok(completed)
    }

    pub fn submit_deposit(
        &mut self,
        venue_id: Option<&str>,
        account_id: AccountId,
        asset_id: impl Into<String>,
        amount: Money,
    ) -> Result<VenueTransfer, SimulationRoomError> {
        let mut staged = self.clone();
        let transfer =
            staged.submit_deposit_inner(venue_id, account_id, asset_id.into(), amount)?;
        let venue = venue_id.unwrap_or(&staged.primary_venue_id).to_string();
        staged.record_wallet_transfer(&venue, &transfer);
        *self = staged;
        Ok(transfer)
    }

    fn submit_deposit_inner(
        &mut self,
        venue_id: Option<&str>,
        account_id: AccountId,
        asset_id: String,
        amount: Money,
    ) -> Result<VenueTransfer, SimulationRoomError> {
        let venue_id = venue_id.unwrap_or(&self.primary_venue_id).to_string();
        if amount > 0
            && self
                .portfolios
                .reserve(account_id, asset_id.clone(), amount)
                .is_err()
        {
            let transfer = self.exchange_mut(&venue_id)?.submit_rejected_venue_deposit(
                account_id,
                asset_id,
                amount,
                VenueTransferRejectReason::InsufficientPortfolioBalance,
            );
            return Ok(transfer);
        }

        let transfer = self
            .exchange_mut(&venue_id)?
            .submit_venue_deposit(account_id, asset_id, amount)
            .map_err(SimulationRoomError::Clearing)?;
        if transfer.status != VenueTransferStatus::Pending {
            self.apply_portfolio_effect_for_finished_transfer(&venue_id, &transfer);
        }
        Ok(transfer)
    }

    pub fn submit_withdrawal(
        &mut self,
        venue_id: Option<&str>,
        account_id: AccountId,
        asset_id: impl Into<String>,
        amount: Money,
    ) -> Result<VenueTransfer, SimulationRoomError> {
        let mut staged = self.clone();
        let transfer =
            staged.submit_withdrawal_inner(venue_id, account_id, asset_id.into(), amount)?;
        let venue = venue_id.unwrap_or(&staged.primary_venue_id).to_string();
        staged.record_wallet_transfer(&venue, &transfer);
        *self = staged;
        Ok(transfer)
    }

    fn submit_withdrawal_inner(
        &mut self,
        venue_id: Option<&str>,
        account_id: AccountId,
        asset_id: String,
        amount: Money,
    ) -> Result<VenueTransfer, SimulationRoomError> {
        let venue_id = venue_id.unwrap_or(&self.primary_venue_id).to_string();
        let transfer = self
            .exchange_mut(&venue_id)?
            .submit_venue_withdrawal(account_id, asset_id, amount)
            .map_err(SimulationRoomError::Clearing)?;
        if transfer.status != VenueTransferStatus::Pending {
            self.apply_portfolio_effect_for_finished_transfer(&venue_id, &transfer);
        }
        Ok(transfer)
    }

    pub fn submit_venue_to_venue_transfer(
        &mut self,
        from_venue_id: &str,
        to_venue_id: &str,
        account_id: AccountId,
        asset_id: impl Into<String>,
        amount: Money,
    ) -> Result<VenueToVenueTransfer, SimulationRoomError> {
        let mut staged = self.clone();
        let transfer = staged.submit_venue_to_venue_transfer_inner(
            from_venue_id,
            to_venue_id,
            account_id,
            asset_id.into(),
            amount,
        )?;
        *self = staged;
        Ok(transfer)
    }

    fn submit_venue_to_venue_transfer_inner(
        &mut self,
        from_venue_id: &str,
        to_venue_id: &str,
        account_id: AccountId,
        asset_id: String,
        amount: Money,
    ) -> Result<VenueToVenueTransfer, SimulationRoomError> {
        if !self.exchanges.contains_key(to_venue_id) {
            return Err(SimulationRoomError::VenueNotFound {
                venue_id: to_venue_id.to_string(),
            });
        }
        let withdrawal =
            self.submit_withdrawal(Some(from_venue_id), account_id, asset_id.clone(), amount)?;
        let mut deposit = None;
        if withdrawal.status == VenueTransferStatus::Completed {
            deposit = Some(self.submit_deposit(Some(to_venue_id), account_id, asset_id, amount)?);
        } else if withdrawal.status == VenueTransferStatus::Pending {
            self.pending_venue_transfers.push(PendingVenueTransfer {
                from_venue_id: from_venue_id.to_string(),
                to_venue_id: to_venue_id.to_string(),
                account_id,
                asset_id,
                amount,
                withdrawal_transfer_id: withdrawal.transfer_id,
            });
        }
        Ok(VenueToVenueTransfer {
            from_venue_id: from_venue_id.to_string(),
            to_venue_id: to_venue_id.to_string(),
            withdrawal,
            deposit,
        })
    }

    pub fn transfers(&self) -> Vec<VenueTransfer> {
        self.primary_exchange().transfers()
    }

    pub(crate) fn normalize_after_restore(&mut self) -> Result<(), ActorRejectReason> {
        for exchange in self.exchanges.values_mut() {
            let exchange = Arc::make_mut(exchange);
            exchange
                .normalize_after_restore()
                .map_err(ActorRejectReason::Clearing)?;
        }
        if self.next_command_seq == 0 {
            self.next_command_seq = self.exchanges.values().try_fold(0u64, |total, exchange| {
                total
                    .checked_add(exchange.next_command_seq())
                    .ok_or(ActorRejectReason::Clearing(ClearingError::BalanceOverflow))
            })?;
        }
        Ok(())
    }

    fn take_command_seq(&mut self) -> ActorSeq {
        let command_seq = self.next_command_seq;
        self.next_command_seq = self
            .next_command_seq
            .checked_add(1)
            .expect("simulation room command sequence overflow");
        command_seq
    }

    pub fn asset_ledger(&self) -> &[AssetLedgerEntry] {
        &self.asset_ledger
    }

    pub fn net_worth_snapshot(&self) -> RoomNetWorthSnapshot {
        let mut account_ids = BTreeSet::new();
        for account in self.portfolios.account_snapshots() {
            account_ids.insert(account.account_id);
        }
        for exchange in self.exchanges.values() {
            for account in exchange.venue_account_snapshots() {
                account_ids.insert(account.account_id);
            }
        }

        let accounts = account_ids
            .into_iter()
            .map(|account_id| self.account_net_worth_snapshot(account_id))
            .collect();

        RoomNetWorthSnapshot {
            room_id: self.room_id.clone(),
            accounts,
        }
    }

    fn apply_seed_order(
        &mut self,
        seed_order: ScenarioSeedOrder,
    ) -> Result<ActorExecution, ScenarioError> {
        match seed_order.instrument_id {
            Some(instrument_id) => self
                .apply_to_instrument(&instrument_id, seed_order.command)
                .map_err(ScenarioError::Actor),
            None => Ok(self.apply(seed_order.command)),
        }
    }

    fn exchange_mut(&mut self, venue_id: &str) -> Result<&mut ExchangeActor, SimulationRoomError> {
        self.exchanges
            .get_mut(venue_id)
            .map(Arc::make_mut)
            .ok_or_else(|| SimulationRoomError::VenueNotFound {
                venue_id: venue_id.to_string(),
            })
    }

    pub fn venue_id_for_instrument(&self, instrument_id: &str) -> Option<VenueId> {
        self.exchanges.iter().find_map(|(venue_id, exchange)| {
            exchange
                .has_instrument(instrument_id)
                .then(|| venue_id.clone())
        })
    }

    /// The exchange `venue_id_for_instrument` resolves, without copying its id.
    fn instrument_exchange(
        &self,
        instrument_id: &str,
    ) -> Result<&ExchangeActor, ActorRejectReason> {
        self.exchanges
            .values()
            .find(|exchange| exchange.has_instrument(instrument_id))
            .map(Arc::as_ref)
            .ok_or_else(|| ActorRejectReason::InstrumentNotFound {
                instrument_id: instrument_id.to_string(),
            })
    }

    fn apply_initial_portfolio(&mut self, portfolio: &ScenarioPortfolio) {
        for (asset_id, total) in &portfolio.balances {
            let snapshot =
                self.portfolios
                    .set_balance(portfolio.account_id, asset_id.clone(), *total);
            self.record_asset_ledger(
                None,
                portfolio.account_id,
                asset_id.clone(),
                *total,
                snapshot.total,
                AssetLedgerKind::PortfolioSet,
            );
        }
    }

    fn apply_initial_allocation(
        &mut self,
        venue_id: &str,
        account_id: AccountId,
        asset_id: String,
        amount: Money,
    ) -> Result<(), ScenarioError> {
        if amount <= 0 {
            return Err(ScenarioError::Allocation(
                VenueTransferRejectReason::NonPositiveAmount,
            ));
        }
        let portfolio = self
            .portfolios
            .apply_delta(account_id, asset_id.clone(), -amount)
            .map_err(|_| {
                ScenarioError::Allocation(VenueTransferRejectReason::InsufficientPortfolioBalance)
            })?;
        let venue_result = self
            .exchange_mut(venue_id)
            .map_err(|_| {
                ScenarioError::Allocation(VenueTransferRejectReason::InsufficientAvailableBalance)
            })?
            .apply_venue_asset_delta(account_id, asset_id.clone(), amount);
        if let Err(error) = venue_result {
            let _ = self
                .portfolios
                .apply_delta(account_id, asset_id.clone(), amount);
            return Err(ScenarioError::Allocation(error));
        }
        self.record_asset_ledger(
            Some(venue_id.to_string()),
            account_id,
            asset_id,
            -amount,
            portfolio.total,
            AssetLedgerKind::InitialAllocation,
        );
        Ok(())
    }

    fn apply_portfolio_effect_for_finished_transfer(
        &mut self,
        venue_id: &str,
        transfer: &VenueTransfer,
    ) {
        if transfer.status == VenueTransferStatus::Pending {
            return;
        }

        match (transfer.kind, transfer.status) {
            (VenueTransferKind::Deposit, VenueTransferStatus::Completed) => {
                let _ = self.portfolios.release(
                    transfer.account_id,
                    transfer.asset_id.clone(),
                    transfer.amount,
                );
                if let Ok(snapshot) = self.portfolios.apply_delta(
                    transfer.account_id,
                    transfer.asset_id.clone(),
                    -transfer.amount,
                ) {
                    self.record_asset_ledger(
                        Some(venue_id.to_string()),
                        transfer.account_id,
                        transfer.asset_id.clone(),
                        -transfer.amount,
                        snapshot.total,
                        AssetLedgerKind::DepositCompleted,
                    );
                }
            }
            (VenueTransferKind::Deposit, VenueTransferStatus::Rejected) => {
                let _ = self.portfolios.release(
                    transfer.account_id,
                    transfer.asset_id.clone(),
                    transfer.amount,
                );
            }
            (VenueTransferKind::Withdrawal, VenueTransferStatus::Completed) => {
                if let Ok(snapshot) = self.portfolios.apply_delta(
                    transfer.account_id,
                    transfer.asset_id.clone(),
                    transfer.amount,
                ) {
                    self.record_asset_ledger(
                        Some(venue_id.to_string()),
                        transfer.account_id,
                        transfer.asset_id.clone(),
                        transfer.amount,
                        snapshot.total,
                        AssetLedgerKind::WithdrawalCompleted,
                    );
                }
            }
            (VenueTransferKind::Withdrawal, VenueTransferStatus::Rejected)
            | (_, VenueTransferStatus::Pending) => {}
        }
    }

    fn process_completed_venue_transfer_links(
        &mut self,
        venue_id: &str,
        completed: &[VenueTransfer],
    ) -> Result<Vec<VenueTransfer>, SimulationRoomError> {
        let completed_withdrawals = completed
            .iter()
            .filter(|transfer| {
                transfer.kind == VenueTransferKind::Withdrawal
                    && transfer.status == VenueTransferStatus::Completed
            })
            .map(|transfer| transfer.transfer_id)
            .collect::<BTreeSet<_>>();
        if completed_withdrawals.is_empty() {
            return Ok(Vec::new());
        }

        let mut ready = Vec::new();
        self.pending_venue_transfers.retain(|pending| {
            let is_ready = pending.from_venue_id == venue_id
                && completed_withdrawals.contains(&pending.withdrawal_transfer_id);
            if is_ready {
                ready.push(pending.clone());
                false
            } else {
                true
            }
        });

        let mut transfers = Vec::with_capacity(ready.len());
        for pending in ready {
            transfers.push(self.submit_deposit(
                Some(&pending.to_venue_id),
                pending.account_id,
                pending.asset_id,
                pending.amount,
            )?);
        }
        Ok(transfers)
    }

    fn account_net_worth_snapshot(&self, account_id: AccountId) -> AccountNetWorthSnapshot {
        let mut asset_ids = BTreeSet::new();
        let portfolio = self.portfolios.account_snapshot(account_id);
        for balance in &portfolio.balances {
            asset_ids.insert(balance.asset_id.clone());
        }
        for exchange in self.exchanges.values() {
            for account in exchange.venue_account_snapshots() {
                if account.account_id == account_id {
                    for balance in account.balances {
                        asset_ids.insert(balance.asset_id);
                    }
                }
            }
        }

        let assets = asset_ids
            .into_iter()
            .map(|asset_id| {
                let portfolio_balance = self
                    .portfolios
                    .balance_snapshot(account_id, &asset_id)
                    .map(|balance| (balance.total, balance.reserved, balance.available))
                    .unwrap_or_default();
                let mut venue_total = 0;
                let mut venue_reserved = 0;
                for exchange in self.exchanges.values() {
                    if let Some(balance) = exchange.venue_balance_snapshot(account_id, &asset_id) {
                        venue_total += balance.total;
                        venue_reserved += balance.reserved;
                    }
                }
                AccountNetWorthAssetSnapshot {
                    asset_id,
                    portfolio_total: portfolio_balance.0,
                    portfolio_reserved: portfolio_balance.1,
                    portfolio_available: portfolio_balance.2,
                    venue_total,
                    venue_reserved,
                    venue_available: venue_total - venue_reserved,
                    total: portfolio_balance.0 + venue_total,
                    available: portfolio_balance.2 + venue_total - venue_reserved,
                }
            })
            .collect();

        AccountNetWorthSnapshot { account_id, assets }
    }

    fn record_asset_ledger(
        &mut self,
        venue_id: Option<VenueId>,
        account_id: AccountId,
        asset_id: String,
        delta: Money,
        portfolio_balance_after: Money,
        kind: AssetLedgerKind,
    ) {
        let seq = self.next_asset_ledger_seq;
        self.next_asset_ledger_seq += 1;
        self.asset_ledger.push(AssetLedgerEntry {
            seq,
            account_id,
            venue_id,
            asset_id,
            delta,
            portfolio_balance_after,
            kind,
            step: self.clock().step(),
        });
    }
}

#[derive(Clone, Debug)]
pub struct SimulationBootstrap {
    pub room: SimulationRoom,
    pub seed_executions: Vec<ActorExecution>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct VenueAccountVenueSnapshot {
    pub venue_id: VenueId,
    pub account: VenueAccountSnapshot,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct PendingVenueTransfer {
    pub from_venue_id: VenueId,
    pub to_venue_id: VenueId,
    pub account_id: AccountId,
    pub asset_id: String,
    pub amount: Money,
    pub withdrawal_transfer_id: u64,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct VenueToVenueTransfer {
    pub from_venue_id: VenueId,
    pub to_venue_id: VenueId,
    pub withdrawal: VenueTransfer,
    pub deposit: Option<VenueTransfer>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct AssetLedgerEntry {
    pub seq: u64,
    pub account_id: AccountId,
    pub venue_id: Option<VenueId>,
    pub asset_id: String,
    pub delta: Money,
    pub portfolio_balance_after: Money,
    pub kind: AssetLedgerKind,
    pub step: u64,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum AssetLedgerKind {
    PortfolioSet,
    InitialAllocation,
    DepositCompleted,
    WithdrawalCompleted,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct RoomNetWorthSnapshot {
    pub room_id: RoomId,
    pub accounts: Vec<AccountNetWorthSnapshot>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct AccountNetWorthSnapshot {
    pub account_id: AccountId,
    pub assets: Vec<AccountNetWorthAssetSnapshot>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct AccountNetWorthAssetSnapshot {
    pub asset_id: String,
    pub portfolio_total: Money,
    pub portfolio_reserved: Money,
    pub portfolio_available: Money,
    pub venue_total: Money,
    pub venue_reserved: Money,
    pub venue_available: Money,
    pub total: Money,
    pub available: Money,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SimulationRoomError {
    VenueNotFound { venue_id: VenueId },
    Clearing(ClearingError),
    Clock(crate::clock::ClockError),
    Closed,
}

fn rules_for_exchange(
    scenario: &ScenarioConfig,
    exchange_config: &ExchangeConfig,
) -> Result<VenueRuleConfig, ScenarioError> {
    match &scenario.venue_preset {
        Some(preset) => preset
            .rules_for_markets(&exchange_config.markets)
            .map_err(|error| ScenarioError::MarketConfig(MarketConfigError::VenueRule(error)))
            .map(|rules| rules.merge_overrides(scenario.venue_rules.clone())),
        None => Ok(scenario.venue_rules.clone()),
    }
}

fn asset_policy_for_exchange(
    scenario: &ScenarioConfig,
    exchange_config: &ExchangeConfig,
) -> VenueAssetPolicyConfig {
    match &scenario.venue_preset {
        Some(preset) => preset
            .asset_policy_for_markets(&exchange_config.markets)
            .merge_overrides(scenario.venue_asset_policy.clone()),
        None => scenario.venue_asset_policy.clone(),
    }
}

fn scenario_user_accounts(scenario: &ScenarioConfig) -> BTreeMap<UserId, BTreeSet<AccountId>> {
    let accounts = scenario
        .accounts
        .iter()
        .map(|account| match account {
            ScenarioAccount::Basic { account_id, .. }
            | ScenarioAccount::Spot { account_id, .. } => *account_id,
        })
        .collect::<BTreeSet<_>>();
    BTreeMap::from([(String::from("default-user"), accounts)])
}

fn apply_account_to_exchange(
    account: &ScenarioAccount,
    exchange: &mut ExchangeActor,
) -> Result<(), ScenarioError> {
    match account {
        ScenarioAccount::Basic {
            account_id,
            cash_balance,
        } => {
            exchange.create_account(*account_id, *cash_balance);
            Ok(())
        }
        ScenarioAccount::Spot {
            account_id,
            cash_balance,
            position_qty,
        } => {
            if exchange.primary_market().kind() == MarketKind::Spot {
                exchange
                    .create_spot_account_with_position(*account_id, *cash_balance, *position_qty)
                    .map_err(ScenarioError::Actor)?;
            } else {
                exchange.create_account(*account_id, *cash_balance);
            }
            Ok(())
        }
    }
}
