$ErrorActionPreference='Stop'
$surpriseRoot='E:\projects\MarketForge-tuning\.local\strategy-research-flow-surprise-20261025'
$surpriseDeadline=[DateTime]::UtcNow.AddHours(6)
while([DateTime]::UtcNow -lt $surpriseDeadline -and -not (Test-Path -LiteralPath (Join-Path $surpriseRoot 'host-memory-monitor.stop'))){
    $osSurprise=Get-CimInstance Win32_OperatingSystem
    $pulseSurprise=[pscustomobject]@{unix_seconds=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds();free_commit_kib=$osSurprise.FreeVirtualMemory;available_physical_kib=$osSurprise.FreePhysicalMemory}
    $pulseSurprise|ConvertTo-Json -Compress|Set-Content -LiteralPath (Join-Path $surpriseRoot 'host-memory.tmp') -Encoding utf8
    Move-Item -LiteralPath (Join-Path $surpriseRoot 'host-memory.tmp') -Destination (Join-Path $surpriseRoot 'host-memory.json') -Force
    Start-Sleep -Seconds 5
}
