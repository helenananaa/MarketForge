$ErrorActionPreference = 'Stop'
$studyRoot = 'E:\projects\MarketForge-tuning\.local\strategy-research-wicks-20261025'
$donePath = Join-Path $studyRoot 'full-sliced\native-s7-sliced.run.json'
$deadlineStudy = [DateTime]::UtcNow.AddMinutes(60)
while ($true) {
    if ([DateTime]::UtcNow -gt $deadlineStudy) { throw 'Timed out; no process stopped.' }
    if (Test-Path -LiteralPath $donePath) {
        try { $runStudy = Get-Content -Raw -LiteralPath $donePath | ConvertFrom-Json; if ($runStudy.complete) { break } } catch { }
    }
    Start-Sleep -Milliseconds 500
}
$nativeStudy = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'candidate.exe' -and $_.ExecutablePath -eq ($studyRoot+'\full-sliced\candidate.exe') })
if ($nativeStudy.Count -ne 0) { throw 'A native process is still running; refuse to stop anything.' }
$launcherStudy = Get-CimInstance Win32_Process -Filter 'ProcessId=49116'
if (-not $launcherStudy) { throw 'Launcher no longer exists; nothing stopped.' }
if ($launcherStudy.CommandLine -ne '"D:\anaconda\python.exe" scripts/research_wick_full.py run sliced') { throw 'Launcher identity changed; refuse to stop.' }
$expectedCreation = [DateTimeOffset]::Parse('2026-10-25T14:15:08.601327+08:00').UtcDateTime
if ($launcherStudy.CreationDate.ToUniversalTime() -ne $expectedCreation) { throw 'Launcher creation time changed; refuse to stop.' }
Stop-Process -Id 49116
[pscustomobject]@{ stopped_at=[DateTimeOffset]::Now.ToString('o'); launcher_pid=49116; native_processes_cancelled=0; completed_seed7_receipt_sha256=$runStudy.receipt_sha256; reason='Entire reactive-only candidate rejected; unstarted seeds19/73 are not qualification successes. Original plan and receipts preserved.' } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $studyRoot 'phase1-launcher-stop-result.json') -Encoding utf8
