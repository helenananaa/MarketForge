from pathlib import Path
import sys
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from research_causal_trace import run
base=root/'.local/strategy-research-wicks-20261025';out=base/'compatibility-old';out.mkdir(exist_ok=False)
run(out,'native-s41-old',base/'control.exe',root/'.local/strategy-research-causal-20261025/full-study/native-s41-depth.recipe.json',14400)
