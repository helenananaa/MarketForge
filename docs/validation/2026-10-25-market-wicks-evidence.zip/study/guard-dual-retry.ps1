$ErrorActionPreference='Stop'
$studyRoot='E:\projects\MarketForge-tuning\.local\strategy-research-wicks-20261025\full-dual-retry'
$binaryStudy=Join-Path $studyRoot 'candidate.exe'
$seenLauncher=$false
$deadlineStudy=[DateTime]::UtcNow.AddHours(8)
while([DateTime]::UtcNow -lt $deadlineStudy){
    $launchers=@(Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object { $_.CommandLine -like '*research_wick_full.py run dual-execution --output .local/strategy-research-wicks-20261025/full-dual-retry*' })
    if($launchers.Count -gt 1){throw 'Ambiguous owned launcher; no process stopped.'}
    if($launchers.Count -eq 1){$seenLauncher=$true}
    $nativeStudy=@(Get-CimInstance Win32_Process -Filter "Name='candidate.exe'" | Where-Object { $_.ExecutablePath -eq $binaryStudy })
    if($seenLauncher -and $launchers.Count -eq 0 -and $nativeStudy.Count -eq 0){break}
    $freeStudy=(Get-CimInstance Win32_OperatingSystem).FreeVirtualMemory
    [pscustomobject]@{time=[DateTimeOffset]::Now.ToString('o');free_commit_kib=$freeStudy;native_pids=@($nativeStudy|ForEach-Object {$_.ProcessId})}|ConvertTo-Json -Compress|Add-Content -LiteralPath (Join-Path $studyRoot 'resource-samples.jsonl') -Encoding utf8
    if($freeStudy -lt (3*1024*1024) -and $nativeStudy.Count -gt 0){
        if($launchers.Count -ne 1){throw 'Cannot verify owned parent; no process stopped.'}
        foreach($procStudy in $nativeStudy){
            if($procStudy.ParentProcessId -ne $launchers[0].ProcessId){throw 'Native parent identity mismatch; no process stopped.'}
            if($procStudy.CommandLine -notlike '*full-dual-retry\native-s*-dual-execution.recipe.json 43200 1'){throw 'Native command identity mismatch; no process stopped.'}
            Stop-Process -Id $procStudy.ProcessId
            [pscustomobject]@{time=[DateTimeOffset]::Now.ToString('o');process_id=$procStudy.ProcessId;executable=$procStudy.ExecutablePath;command=$procStudy.CommandLine;free_commit_kib=$freeStudy;reason='Only the owned native was stopped because system commit fell below3GiB. Preserve this interrupted attempt; no WSL/other project/OS setting changed.'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $studyRoot ('resource-stop-'+[DateTime]::Now.ToString('yyyyMMddHHmmss')+'.json')) -Encoding utf8
        }
        break
    }
    Start-Sleep -Seconds 5
}
