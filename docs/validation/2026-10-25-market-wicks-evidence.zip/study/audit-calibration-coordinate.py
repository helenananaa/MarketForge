import json,sys
from collections import defaultdict
from pathlib import Path
import numpy as np
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from analyze_market_mechanisms import sha,write
source=root/'.local/strategy-research-causal-20261025/diagnostic-s41-depth.trace.jsonl';base=root/'.local/strategy-research-wicks-20261025'
names=('maker-spot-0','maker-perp-17');previous={};records=defaultdict(list)
with source.open(encoding='utf-8') as f:
    for line in f:
        if not any('"'+name+'"' in line for name in names):continue
        r=json.loads(line)
        if r['kind']!='decision' or r['participant'] not in names:continue
        name=r['participant'];v=r['observation'];old=r['before'];prior=previous.get(name)
        if prior and prior['time']==old['last_ms'] and prior['bid'] is not None and prior['ask'] is not None:
            bars=[b for b in v['closed_candles'] if b['is_final'] and old['last_ms']<=b['open_time_ms']<v['time_ms'] and b['close_time_ms']<=v['time_ms']]
            if bars:
                old_depth=max(max(b['high_tick']-old['last_mid'],old['last_mid']-b['low_tick'],0) for b in bars)
                penetration=max(max(b['high_tick']-prior['ask'],prior['bid']-b['low_tick'],0) for b in bars)
                records[name].append(dict(time_ms=v['time_ms'],old_depth_ticks=old_depth,penetration_ticks=penetration,starting_half_spread_ticks=(prior['ask']-prior['bid'])/2))
        book=v['book'];previous[name]=dict(time=v['time_ms'],bid=book['bids'][0]['price_tick'] if book['bids'] else None,ask=book['asks'][0]['price_tick'] if book['asks'] else None)
summary={name:dict(observations=len(rs),median_depth_ticks=float(np.median([r['old_depth_ticks'] for r in rs])),
    median_penetration_ticks=float(np.median([r['penetration_ticks'] for r in rs])),zero_penetration_fraction=sum(r['penetration_ticks']==0 for r in rs)/len(rs),
    old_hit24_without_penetration24=sum(r['old_depth_ticks']>=24 and r['penetration_ticks']<24 for r in rs)/len(rs)) for name,rs in records.items()}
write(base/'calibration-coordinate-audit.json',dict(source_sha256=sha(source),records=dict(records),summary=summary,
    scope='Two fixed maker IDs in the already selected depth-trace window. Exact preceding observed public touch, not a future book. Repeated participant/candle contexts are descriptive, not independent evidence. This illustrates the estimator coordinate change; it does not establish that the proposed alternative is equivalent to GLFT or will improve candles.'))
print(json.dumps(summary,indent=2))
