$ErrorActionPreference = 'Stop'
$pythonExe = 'E:\projects\MarketForge\.venv\Scripts\python.exe'
$sequence = @(
    @{Stage='stage3'; Label='stage3-http-profile'},
    @{Stage='stage3'; Label='stage3-http-repeat'},
    @{Stage='stage2'; Label='stage2-http-repeat'},
    @{Stage='stage1'; Label='stage1-http-repeat'},
    @{Stage='baseline'; Label='baseline-http-repeat'}
)
foreach ($run in $sequence) {
    Write-Output ('start ' + $run.Label)
    $server = '.local/macro-20261024/' + $run.Stage + '-profile-server.exe'
    $destination = '.local/macro-20261024/' + $run.Label
    & $pythonExe scripts/benchmark_pine_ecosystem.py --ecosystem-recipe .local/tuning/s3000.json --server $server --output $destination --counts 201 --seconds 45 --warmup 5 --interval-ms 250 --population pine --pine-in-process --plugin-dir .local/pine-direct-20261023/python-canonical/bot-plugins --max-memory-mib 4096 --require-bot-receipts --trace-graceful-shutdown
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
