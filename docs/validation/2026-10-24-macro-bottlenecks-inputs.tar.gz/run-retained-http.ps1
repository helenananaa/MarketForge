$ErrorActionPreference = 'Stop'
$pythonExe = 'E:\projects\MarketForge\.venv\Scripts\python.exe'
$sequence = @(
    @{Stage='baseline'; Label='baseline-http-retained1'},
    @{Stage='stage1'; Label='stage1-http-retained1'},
    @{Stage='retained'; Label='retained-http-clean1'},
    @{Stage='retained'; Label='retained-http-clean2'},
    @{Stage='stage1'; Label='stage1-http-retained2'},
    @{Stage='baseline'; Label='baseline-http-retained2'}
)
foreach ($run in $sequence) {
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        $quiet = 0
        while ($quiet -lt 1) {
            if (Get-Process cargo,rustc,cl,link -ErrorAction SilentlyContinue) { $quiet = 0 } else { $quiet++ }
            Start-Sleep -Seconds 10
        }
        $label = $run.Label
        if ($attempt -gt 1) { $label += '-try' + $attempt }
        Write-Output ('start ' + $label)
        $server = '.local/macro-20261024/' + $run.Stage + '-profile-server.exe'
        $destination = '.local/macro-20261024/' + $label
        & $pythonExe scripts/benchmark_pine_ecosystem.py --ecosystem-recipe .local/tuning/s3000.json --server $server --output $destination --counts 201 --seconds 45 --warmup 5 --interval-ms 250 --population pine --pine-in-process --plugin-dir .local/pine-direct-20261023/python-canonical/bot-plugins --max-memory-mib 4096 --require-bot-receipts --trace-graceful-shutdown
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
        $report = Get-Content ($destination + '/bots-201/report.json') -Raw | ConvertFrom-Json
        if ($report.process_tree.compiler_nonempty_samples -eq 0) { break }
        Write-Output ('exclude compiler overlap: ' + $label)
        if ($attempt -eq 3) { throw 'Compiler overlap repeated three times; evidence retained.' }
    }
}

