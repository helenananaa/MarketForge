//! Immutable encoding of cold replay chunks. Reuse always compares every source
//! byte; this cache is not an authority, checksum, or replacement for a seal.
use serde_json::Value;
use std::{ops::Range, sync::Arc};

pub(super) struct Chunks {
    json: String,
    ranges: Vec<Range<usize>>,
}

impl Chunks {
    fn new(value: &Value) -> Option<Self> {
        let chunks = value.as_array()?;
        let mut json = String::from("[");
        let mut ranges = Vec::with_capacity(chunks.len());
        for (index, value) in chunks.iter().enumerate() {
            let text = value.as_str()?;
            // Only this exact alphabet admits raw insertion in both canonical
            // encoders. Malformed/restored strings use the ordinary checked path.
            if !text.bytes().all(|b| b.is_ascii_hexdigit()) {
                return None;
            }
            if index != 0 {
                json.push(',');
            }
            json.push('"');
            let start = json.len();
            json.push_str(text);
            ranges.push(start..json.len());
            json.push('"');
        }
        json.push(']');
        Some(Self { json, ranges })
    }

    pub(super) fn matches(&self, value: &Value) -> bool {
        value.as_array().is_some_and(|values| {
            values.len() == self.ranges.len()
                && values.iter().zip(&self.ranges).all(|(value, range)| {
                    value
                        .as_str()
                        .is_some_and(|s| self.json.as_bytes()[range.clone()] == *s.as_bytes())
                })
        })
    }

    pub(super) fn write_json(&self, spaced: bool, out: &mut String) {
        if !spaced {
            out.push_str(&self.json);
            return;
        }
        out.push('[');
        for (i, range) in self.ranges.iter().enumerate() {
            if i != 0 {
                out.push_str(", ");
            }
            out.push('"');
            out.push_str(&self.json[range.clone()]);
            out.push('"');
        }
        out.push(']');
    }

    pub(super) fn len(&self, spaced: bool) -> usize {
        self.json.len()
            + if spaced {
                self.ranges.len().saturating_sub(1)
            } else {
                0
            }
    }
}

pub(super) fn bind(state: &Value, previous: Option<Arc<Chunks>>) -> Option<Arc<Chunks>> {
    if state["broker_schema"] != 4 {
        return None;
    }
    let chunks = &state["vm_checkpoint"]["chunks"];
    match previous {
        Some(previous) if previous.matches(chunks) => Some(previous),
        _ => Chunks::new(chunks).map(Arc::new),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    #[test]
    fn archive_encoding_is_exact_and_reuse_requires_every_byte() {
        let state =
            json!({"broker_schema":4,"vm_checkpoint":{"chunks":["abcdef0123","ABCDEF",""]}});
        let cache = bind(&state, None).unwrap();
        assert!(Arc::ptr_eq(
            &cache,
            &bind(&state, Some(cache.clone())).unwrap()
        ));
        for spaced in [false, true] {
            let mut text = String::new();
            cache.write_json(spaced, &mut text);
            let expected =
                super::super::json_compat::python_json(&state["vm_checkpoint"]["chunks"], spaced)
                    .unwrap();
            assert_eq!(text, expected);
            assert_eq!(cache.len(spaced), text.len());
        }
        for changed in [
            json!([]),
            json!(["abcdef0124", "ABCDEF", ""]),
            json!(["abcdef0123", "ABCDEF"]),
            json!(["abcdef0123", "ABCDEF", "", "00"]),
        ] {
            assert!(!cache.matches(&changed));
        }
        for invalid in [
            json!(["x"]),
            json!(["\"}"]),
            json!(["策略"]),
            json!([null]),
            Value::Null,
        ] {
            assert!(Chunks::new(&invalid).is_none());
        }
    }
}
