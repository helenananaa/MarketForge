//! A private, complete byte cache for schema-3 VM reuse. It is neither a hash
//! nor durable state. Public execution seals still validate first; a mismatch
//! takes the original VM checkpoint/tail reconstruction path.
use super::archive_cache::{self, Chunks};
use serde::Serialize;
use serde_json::Value;
use std::io::{self, Write};
use std::sync::Arc;

#[derive(Default)]
pub(super) struct Stamp {
    bytes: Vec<u8>,
    pub(super) archive: Option<Arc<Chunks>>,
}

// Match the old stamp's sorted JSON object. Value indexing intentionally maps
// both absent and explicit-null fields to null, as the previous comparison did.
#[derive(Serialize)]
struct Payload<'a> {
    checkpoint: &'a Value,
    intents: &'a Value,
    tail: &'a Value,
}

fn payload(state: &Value) -> Payload<'_> {
    Payload {
        checkpoint: &state["vm_checkpoint"],
        intents: &state["vm_tail_intents"],
        tail: &state["vm_tail"],
    }
}

impl Stamp {
    pub(super) fn update(&mut self, state: &Value) -> Result<(), serde_json::Error> {
        self.bytes.clear();
        self.archive = archive_cache::bind(state, self.archive.take());
        encode(state, self.archive.is_some(), &mut self.bytes)
    }

    pub(super) fn matches(&self, state: &Value) -> bool {
        if self
            .archive
            .as_ref()
            .is_some_and(|a| !a.matches(&state["vm_checkpoint"]["chunks"]))
        {
            return false;
        }
        let mut writer = CompareWriter::new(&self.bytes);
        encode(state, self.archive.is_some(), &mut writer).is_ok() && writer.finished()
    }
}

fn encode(state: &Value, archive: bool, out: &mut impl Write) -> Result<(), serde_json::Error> {
    if !archive {
        return serde_json::to_writer(out, &payload(state));
    }
    // The cold chunks live once in the shared encoding. Header/tail equality is
    // still exact, including unknown fields and numeric representations.
    let checkpoint: std::collections::BTreeMap<_, _> = state["vm_checkpoint"]
        .as_object()
        .unwrap()
        .iter()
        .filter(|(k, _)| k.as_str() != "chunks")
        .collect();
    serde_json::to_writer(
        out,
        &(&checkpoint, &state["vm_tail_intents"], &state["vm_tail"]),
    )
}

struct CompareWriter<'a> {
    expected: &'a [u8],
    offset: usize,
    mismatched: bool,
}

impl<'a> CompareWriter<'a> {
    fn new(expected: &'a [u8]) -> Self {
        Self {
            expected,
            offset: 0,
            mismatched: false,
        }
    }

    fn finished(&self) -> bool {
        !self.mismatched && self.offset == self.expected.len()
    }
}

impl Write for CompareWriter<'_> {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        if let Some(end) = self.offset.checked_add(bytes.len()) {
            self.mismatched |= self.expected.get(self.offset..end) != Some(bytes);
            self.offset = end;
        } else {
            self.mismatched = true;
        }
        // Compare through the end without allocating an error for a mismatch.
        // Complete length equality prevents matching a prefix or trailing data.
        Ok(bytes.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

#[cfg(test)]
#[path = "stamp_cache_tests.rs"]
mod tests;
