$ErrorActionPreference = 'Stop'
$pythonExe = 'E:\projects\MarketForge\.venv\Scripts\python.exe'
$env:PATH = 'E:\projects\MarketForge\.venv\Scripts;' + $env:PATH
$env:PYTHONPATH = 'E:\projects\MarketForge-tuning\bot-plugins\pine-strategy\.runtime\strategy-ecosystem;E:\projects\MarketForge-tuning\python;E:\projects\MarketForge-tuning\python\tests'
& $pythonExe scripts/qualify_pine_direct.py --probe E:\projects\MarketForge-tuning\.local\macro-20261024\stage3-profile-probe.exe --output .local/macro-20261024/qualification-correct --bars 512 --replay-state --check-migration --timeout-ms 5000 > .local/macro-20261024/qualification-correct.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $pythonExe scripts/validate_pine_direct_recovery.py --exe E:\projects\MarketForge-tuning\.local\macro-20261024\stage3-profile.exe --cwd E:\projects\MarketForge-tuning\.local\pine-direct-20261023\python-canonical --recipe .local/tuning/long24.json --segment-steps 70 --replay-state --require-direct-segments --output .local/macro-20261024/recovery > .local/macro-20261024/recovery.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$env:MARKETFORGE_PINE_PROBE = 'E:\projects\MarketForge-tuning\.local\macro-20261024\stage3-profile-probe.exe'
$env:MARKETFORGE_REQUIRE_INPROCESS_TESTS = '1'
$env:MARKETFORGE_REQUIRE_INCREMENTAL_TESTS = '1'
& $pythonExe -m unittest test_pine_bot test_pine_broker test_pine_inprocess test_pine_replay test_bot_runtime_receipts test_strategy_runtime > .local/macro-20261024/python-tests.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& .local/macro-20261024/run-http-clean.ps1 > .local/macro-20261024/http-clean.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $pythonExe scripts/benchmark_research_optimizations.py .local/macro-20261024/control-repeat-plan.json .local/macro-20261024/control-repeat > .local/macro-20261024/control-repeat.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
