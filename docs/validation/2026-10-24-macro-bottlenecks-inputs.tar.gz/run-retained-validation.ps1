$ErrorActionPreference = 'Stop'
$pythonExe = 'E:\projects\MarketForge\.venv\Scripts\python.exe'
$env:PATH = 'E:\projects\MarketForge\.venv\Scripts;' + $env:PATH
$env:PYTHONPATH = 'E:\projects\MarketForge-tuning\bot-plugins\pine-strategy\.runtime\strategy-ecosystem;E:\projects\MarketForge-tuning\python;E:\projects\MarketForge-tuning\python\tests'
$env:MARKETFORGE_PINE_PROBE = 'E:\projects\MarketForge-tuning\.local\macro-20261024\retained-profile-probe.exe'
$env:MARKETFORGE_REQUIRE_INPROCESS_TESTS = '1'
$env:MARKETFORGE_REQUIRE_INCREMENTAL_TESTS = '1'
& $pythonExe -m unittest test_pine_bot test_pine_broker test_pine_inprocess test_pine_replay test_bot_runtime_receipts test_strategy_runtime > .local/macro-20261024/retained-python-tests.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $pythonExe scripts/qualify_pine_direct.py --probe E:\projects\MarketForge-tuning\.local\macro-20261024\retained-profile-probe.exe --output .local/macro-20261024/retained-qualification --bars 512 --replay-state --check-migration --timeout-ms 5000 > .local/macro-20261024/retained-qualification.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& .local/macro-20261024/run-retained-http.ps1 > .local/macro-20261024/retained-http.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $pythonExe scripts/benchmark_research_optimizations.py .local/macro-20261024/retained-research-plan.json .local/macro-20261024/retained-research > .local/macro-20261024/retained-research.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $pythonExe scripts/validate_pine_direct_recovery.py --exe E:\projects\MarketForge-tuning\.local\macro-20261024\retained-profile.exe --cwd E:\projects\MarketForge-tuning\.local\pine-direct-20261023\python-canonical --recipe .local/tuning/long24.json --segment-steps 70 --replay-state --require-direct-segments --output .local/macro-20261024/retained-recovery > .local/macro-20261024/retained-recovery.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
