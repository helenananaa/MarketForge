"""Differential qualification of exact installed Pine sources (no admission writes).

Compare complete schema-2 responses with the installed Python broker, including
cached continuation, cold reconstruction, duplicate calls and rejected orders.
Trading receipts from the real gateway are a separate required acceptance gate.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import random
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python/tests"))
from test_pine_bot import bot
from test_pine_broker import broker_request, perp, ack


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--probe", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, default=ROOT / "exchange-server/src/pine_inprocess/ecosystem-qualified.json")
    parser.add_argument("--bars", type=int, default=256)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    sources = json.loads(args.manifest.read_text(encoding="utf-8"))
    process = subprocess.Popen([str(args.probe), str(ROOT / "bot-plugins/pine-strategy")],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=(args.output / "probe.log").open("w"),
        text=True, encoding="utf-8")
    result = {"scripts": [], "probe_sha256": hashlib.sha256(args.probe.read_bytes()).hexdigest(),
              "manifest_sha256": hashlib.sha256(args.manifest.read_bytes()).hexdigest()}
    import pine_compat
    result["python_runtime"] = {"version": pine_compat.__version__,
        "sha256": hashlib.sha256(Path(pine_compat.__file__).read_bytes()).hexdigest()}
    result["adapter_sha256"] = {name: hashlib.sha256((ROOT / "bot-plugins/pine-strategy" / name).read_bytes()).hexdigest()
        for name in ("bot.py", "broker.py", "incremental.py", "incremental-qualified.json")}
    def rust(req, reset):
        process.stdin.write(json.dumps({"request": req, "reset": reset, "timeout_ms": 30000}) + "\n")
        process.stdin.flush()
        line = process.stdout.readline()
        if not line:
            raise RuntimeError("probe exited; inspect probe.log")
        return json.loads(line)
    try:
        for number, (name, digest) in enumerate(sources.items()):
            started = time.perf_counter()
            source = bot.load_source(name)
            if not bot.incremental_module().qualified(source):
                raise ValueError(f"source lacks independent incremental qualification: {name}")
            if hashlib.sha256(source.encode()).hexdigest() != digest:
                raise ValueError(f"source hash mismatch: {name}")
            row = {"script": name, "sha256": digest, "comparisons": 0, "intents": 0, "actions": 0, "passed": True}
            try:
                for seed in (7, 19):
                    rng = random.Random(seed)
                    prices = [100000 + int(3000 * math.sin(i / 8) + 1500 * math.sin(i / 31)) + rng.randrange(-400, 401) for i in range(args.bars)]
                    previous = None
                    for end in sorted(set((1, 32, 64, 65, 128, 256, args.bars))):
                        req = perp(broker_request(prices[:end]), position=0 if seed == 7 else 7,
                                   avg=0 if seed == 7 else prices[0], cash=100000000)
                        req["config"].update(script=name, quantize_strategy_orders=True, history_limit=2048, max_qty=10, inventory_cap=100)
                        req["participant"]["participant_id"] = f"qualification-{number}-{seed}"
                        req["observation"]["instrument"] = {"tick_size": 1, "lot_size": 1}
                        if previous is not None:
                            ack(req, previous)
                            for receipt in req["state"]["_host_receipts"]:
                                receipt.update(accepted=False, order_id=None, error="qualification rejection")
                        expected = bot.decide(copy.deepcopy(req))
                        actual = rust(req, reset=end in (1, 128))
                        if actual.get("response") != expected:
                            (args.output / f"failure-{number}.json").write_text(json.dumps({"request": req, "expected": expected, "actual": actual}, indent=2), encoding="utf-8")
                            raise AssertionError(actual.get("error", "response mismatch"))
                        row["comparisons"] += 1
                        row["intents"] += len(expected["state"].get("last_intents", []))
                        row["actions"] += len(expected["actions"])
                        if end in (65, args.bars):
                            for reset in (False, True):
                                retry = rust(req, reset)
                                if retry.get("response") != expected:
                                    raise AssertionError("speculative retry or reconstruction mismatch")
                                row["comparisons"] += 1
                        previous = expected
            except Exception as error:
                row.update(passed=False, error=str(error))
            row["seconds"] = time.perf_counter() - started
            result["scripts"].append(row)
            (args.output / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
            print(json.dumps(row), flush=True)
    finally:
        process.stdin.close()
        process.wait(timeout=15)
        process.stdout.close()
    return int(any(not r["passed"] for r in result["scripts"]))


if __name__ == "__main__":
    raise SystemExit(main())
