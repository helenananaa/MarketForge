import json,collections
from pathlib import Path
out=Path(__file__).resolve().parent
result={'scope':'Exploratory diagnosis added after inspecting seed-41 candles; not a selection criterion. Same clock window in all arms. Taker account ownership does not distinguish strategy decisions from forced liquidation. Net quantity is signed taker flow, not a position change.','window_ms':[19800000,23400000],'runs':[]}
for profile in ['baseline','model','model_ack']:
 name=f'native-s41-{profile}'
 recipe=json.loads((out/(name+'.recipe.json')).read_text())
 owners={(a['Plugin']['participant']['account_id'],a['Plugin']['participant']['instrument_id']):a['Plugin'] for a in recipe['agents']}
 raw=json.loads((out/(name+'.receipt.json')).read_text())
 markets={}
 for market in ['V-BTC-SPOT','V-BTC-PERP']:
  roles=collections.defaultdict(lambda:collections.Counter());accounts=collections.defaultdict(lambda:collections.Counter());prices=[]
  for t in raw['trade_receipts']:
   if t['instrument_id']!=market or not 19800000<=t['time_ms']<23400000:continue
   p=owners.get((t['taker_account_id'],market));role=p['plugin_id'] if p else 'external';ident=p['participant']['participant_id'] if p else str(t['taker_account_id'])
   sign=1 if t['taker_side']=='Buy' else -1
   for item in (roles[role],accounts[ident]):
    item['qty']+=t['qty'];item['signed_taker_qty']+=sign*t['qty'];item['trades']+=1
   prices.append(t['price_tick'])
  top=sorted(accounts.items(),key=lambda x:abs(x[1]['signed_taker_qty']),reverse=True)[:10]
  markets[market]=dict(first_price=prices[0],last_price=prices[-1],low=min(prices),high=max(prices),roles=dict(roles),largest_signed_taker_accounts=dict(top))
  print(profile,market,'range',[min(prices),max(prices)],'roles',[(k,v['signed_taker_qty']) for k,v in roles.items()],'top',[(k,v['signed_taker_qty']) for k,v in top[:3]],flush=True)
 result['runs'].append(dict(name=name,receipt_sha256=json.loads((out/(name+'.run.json')).read_text())['receipt_sha256'],markets=markets))
 del raw
(out/'episode-native-s41.json').write_text(json.dumps(result,indent=2)+'\n')
