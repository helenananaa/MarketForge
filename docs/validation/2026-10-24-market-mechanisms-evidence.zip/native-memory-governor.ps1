$ErrorActionPreference='Stop'
$studyRoot='E:\projects\MarketForge-tuning\.local\strategy-research-mechanisms-20261024'
$expectedExe=Join-Path $studyRoot 'candidate.exe'
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class StudyProcess {
 [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
 [DllImport("ntdll.dll")] static extern int NtSuspendProcess(IntPtr h);
 [DllImport("ntdll.dll")] static extern int NtResumeProcess(IntPtr h);
 [DllImport("psapi.dll")] static extern bool EmptyWorkingSet(IntPtr h);
 public static void Set(int pid,bool pause) {
  var h=OpenProcess(0xD00,false,pid); if(h==IntPtr.Zero)throw new Exception("OpenProcess failed");
  try {int status=pause?NtSuspendProcess(h):NtResumeProcess(h); if(status!=0)throw new Exception("NT status "+status);if(pause)EmptyWorkingSet(h);}
  finally{CloseHandle(h);}
 }
}
'@
$paused=@{}
$idle=0
function Record($event,$proc){
 $row=@{time=(Get-Date -Format o);event=$event;pid=$proc.ProcessId;command=$proc.CommandLine}
 $row|ConvertTo-Json -Compress|Add-Content -LiteralPath (Join-Path $studyRoot 'resource-scheduling.jsonl')
 Write-Output "$event $($proc.ProcessId)"
}
try {
 while($true){
  $native=@(Get-CimInstance Win32_Process -Filter "Name='candidate.exe'" | Where-Object {
   $_.ExecutablePath -eq $expectedExe -and $_.CommandLine -match 'native-s[0-9]+-(baseline|model|model_ack)\.recipe\.json'
  })
  foreach($key in @($paused.Keys)){if(-not($native.ProcessId -contains [int]$key)){$paused.Remove($key)}}
  if($native.Count -eq 0){$idle++;if($idle -ge 15){break}}else{$idle=0}
  $active=@($native|Where-Object {-not $paused.ContainsKey([string]$_.ProcessId)})
  $os=Get-CimInstance Win32_OperatingSystem
  if($active.Count -gt 1 -and ($os.FreeVirtualMemory -lt 12582912 -or $os.FreePhysicalMemory -lt 4194304)){
   $victim=$active|Sort-Object @{Expression={if($_.CommandLine -match 'native-s7-baseline'){0}else{1}}},CreationDate -Descending|Select-Object -First 1
   [StudyProcess]::Set($victim.ProcessId,$true);$paused[[string]$victim.ProcessId]=$victim;Record 'pause-native-for-memory' $victim
  }
  if($paused.Count -and ($active.Count -eq 0 -or $os.FreeVirtualMemory -gt 25165824)){
   $resume=$paused.Values|Sort-Object CreationDate|Select-Object -First 1
   [StudyProcess]::Set($resume.ProcessId,$false);$paused.Remove([string]$resume.ProcessId);Record 'resume-native' $resume
  }
  Start-Sleep -Seconds 2
 }
} finally {
 foreach($proc in $paused.Values){
  $live=Get-CimInstance Win32_Process -Filter "ProcessId=$($proc.ProcessId)" -ErrorAction SilentlyContinue
  if($live -and $live.ExecutablePath -eq $expectedExe -and $live.CreationDate -eq $proc.CreationDate){[StudyProcess]::Set($proc.ProcessId,$false);Record 'finally-resume-native' $proc}
 }
}
