import csv, json, sys, statistics
from pathlib import Path
from datetime import datetime
from collections import Counter

root=Path.cwd();out=root/'.local/strategy-research-mechanisms-20261024'
sys.path.insert(0,str(root/'scripts'))
from research_market_mechanisms import ensure_runtime_inputs,sha,write
plan=json.loads((out/'plan.json').read_text())
ensure_runtime_inputs(out,plan['runs'])
with (out/'runtime-verifications.jsonl').open('a',encoding='utf-8') as f:
    f.write(json.dumps(dict(time=datetime.now().astimezone().isoformat(),phase='final_after_all_runs',matched=True,manifest_sha256=sha(out/'runtime-inputs.json')))+'\n')
c=json.loads((out/'comparison.json').read_text())
assert c['terminal'] and not c['complete'] and len(c['runs'])==12 and len(c['failed_runs'])==3 and not c['pending_runs']
rows=list(csv.DictReader((out/'comparison.csv').open()))
keys=['return_std_bp','return_acf1','abs_return_acf1','abs_return_p99_bp','abs_return_max_bp','two_sided_fraction','spread_median_bp','reactive_taker_share','bid_depth_25bp_median','ask_depth_25bp_median']
aggregate=[]
for market in ['V-BTC-SPOT','V-BTC-PERP']:
    for profile in ['baseline','model','model_ack']:
        data=[r for r in rows if r['market']==market and r['profile']==profile]
        aggregate.append(dict(market=market,profile=profile,seeds=[int(r['seed']) for r in data],metrics={k:dict(mean=statistics.mean(float(r[k]) for r in data),min=min(float(r[k]) for r in data),max=max(float(r[k]) for r in data)) for k in keys}))
coverage=[]
for r in c['runs']:
    cv=r['coverage'];assets=r['asset_checks']
    assert r['integrity']['self_trades']==0 and r['integrity']['count_matches']
    assert not assets['after']['negative_available'] and assets['total_deltas']['V']==0
    coverage.append(dict(name=r['name'],technical_ready=sum(t['ready'] for t in cv['technical']),technical_total=len(cv['technical']),execution_complete=sum(x['completed_qty']==x['target_qty'] for x in cv['execution']),execution_total=len(cv['execution']),maker_calibrated=sum(bool(x['calibrated']) for x in cv['makers']),maker_total=len(cv['makers']),rejected_actions=r['rejected_actions'],asset_deltas=assets['total_deltas'],trades=r['integrity']['unique_trades']))
events=[json.loads(x) for x in (out/'resource-scheduling.jsonl').read_text().splitlines()]
balances=Counter()
for e in events:balances[e['pid']]+=1 if e['event']=='pause-native-for-memory' else -1
assert not any(balances.values()),balances
summary=dict(complete_runs=12,failed_runs=3,aggregate=aggregate,coverage=coverage,native_scheduling_events=len(events),all_pauses_resumed=True)
write(out/'final-summary.json',summary)
for row in aggregate:
    print(row['market'],row['profile'],{k:round(v['mean'],4) for k,v in row['metrics'].items()})
print('COVERAGE',json.dumps(coverage))
print('Runtime files unchanged, all pauses resumed:',len(events))
