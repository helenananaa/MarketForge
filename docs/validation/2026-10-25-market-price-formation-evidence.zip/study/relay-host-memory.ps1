$ErrorActionPreference='Stop'
$studyMemoryRoot='E:\projects\MarketForge-tuning\.local\strategy-research-price-formation-20261025'
$memoryDeadline=[DateTime]::UtcNow.AddHours(8)
while([DateTime]::UtcNow -lt $memoryDeadline -and -not (Test-Path -LiteralPath (Join-Path $studyMemoryRoot 'host-memory-monitor.stop'))){
    $pulseStudy=[pscustomobject]@{unix_seconds=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds();free_commit_kib=(Get-CimInstance Win32_OperatingSystem).FreeVirtualMemory}
    $tempPulse=Join-Path $studyMemoryRoot 'host-memory.tmp'
    $pulseStudy|ConvertTo-Json -Compress|Set-Content -LiteralPath $tempPulse -Encoding utf8
    Move-Item -LiteralPath $tempPulse -Destination (Join-Path $studyMemoryRoot 'host-memory.json') -Force
    Start-Sleep -Seconds 5
}
