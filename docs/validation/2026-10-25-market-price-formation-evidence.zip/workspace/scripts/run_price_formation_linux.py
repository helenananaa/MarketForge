"""Run immutable Windows-path plans inside WSL using the existing guest memory."""
import argparse,json,os,subprocess,time
from pathlib import Path
from research_market_mechanisms import ROOT,sha,write


def local_path(p):
    p=str(p).replace('\\','/')
    return Path('/mnt/'+p[0].lower()+p[2:] if len(p)>2 and p[1]==':'else p)


def memory():
    fields={r.split(':')[0]:int(r.split()[1])for r in Path('/proc/meminfo').read_text().splitlines()if r.startswith(('MemAvailable:','SwapFree:'))}
    # This host disables WSL Windows-executable interop. A read-only Windows
    # guardian relays commit headroom atomically; stale/missing relay fails shut.
    pulse=ROOT/'.local/strategy-research-price-formation-20261025/host-memory.json'
    try:
        seen=json.loads(pulse.read_text(encoding='utf-8-sig'));age=time.time()-seen['unix_seconds']
        host=int(seen['free_commit_kib'])if 0<=age<30 else 0
    except (OSError,ValueError,KeyError):host=0;age=-1
    return dict(linux_available_kib=fields['MemAvailable'],linux_swap_free_kib=fields['SwapFree'],host_free_commit_kib=host,host_heartbeat_age_seconds=age)


def finish_result(result,receipt,row):
    """A clean systemd proxy exit is insufficient after an explicit guard stop."""
    if result['exit_code']==0 and not result.get('failure'):
        try:
            data=json.loads(receipt.read_text(encoding='utf-8'))
            valid=(data['steps']==row['steps']and data['clock_step_seconds']==row['seconds']
                and data['simulation_time_ms']==row['steps']*row['seconds']*1000)
            if not valid:raise ValueError('Receipt does not cover the requested fixed clock/horizon')
            result.update(complete=True,trades=data['trades'],receipt_sha256=sha(receipt),simulation_time_ms=data['simulation_time_ms'])
        except (ValueError,KeyError,OSError)as error:
            result.update(complete=False,failure='Invalid or incomplete native receipt: '+str(error))
    if not result.get('complete'):
        result.update(complete=False,partial_receipt_bytes=receipt.stat().st_size,partial_receipt_sha256=sha(receipt))
    return result


def run(out,seed=None):
    out=local_path(out);p=json.loads((out/'plan.json').read_text(encoding='utf-8'));binary=out/'candidate.exe'
    assert sha(binary)==p['binary_sha256']
    runtime=json.loads((out/'runtime-inputs.json').read_text(encoding='utf-8'))
    for f in runtime['files']:assert sha(ROOT/f['path'].replace('\\','/'))==f['sha256']
    for row in p['runs']:
        if seed is not None and row['seed']!=seed:continue
        done=out/(row['name']+'.run.json');assert not done.exists(),'Preserve attempts in a fresh directory'
        while True:
            m=memory()
            with (out/'resource-gates.jsonl').open('a') as f:f.write(json.dumps(dict(time=time.time(),**m))+'\n')
            if m['linux_available_kib']>=p['minimum_linux_available_gib']*1024*1024 and m['host_free_commit_kib']>=p['minimum_host_commit_gib']*1024*1024:break
            time.sleep(20)
        recipe=local_path(row['recipe']);assert sha(recipe)==row['recipe_sha256']
        env=dict(os.environ,RESEARCH_PLUGIN_WAKES='events',MARKETFORGE_PINE_IN_PROCESS='1',MARKETFORGE_PINE_REPLAY_STATE='1',MARKETFORGE_BOT_WORKERS='8',RAYON_NUM_THREADS='8')
        for key in ('MF_RESEARCH_CHECKPOINT','MF_RESEARCH_STOP_FILE','MF_RESEARCH_DEADLINE_UNIX','RESEARCH_PLUGIN_POLL_MS','RESEARCH_AUDIT','RESEARCH_PROFILE','RESEARCH_SCRIPT_PROFILE','MF_RESEARCH_TRACE_PATH','MF_RESEARCH_TRACE_WINDOWS'):env.pop(key,None)
        start=time.monotonic();receipt=out/(row['name']+'.receipt.json')
        result=dict(name=row['name'],complete=False,platform='linux-wsl',inputs=dict(recipe_sha256=row['recipe_sha256'],binary_sha256=p['binary_sha256'],steps=row['steps'],seconds=row['seconds']))
        print('START '+row['name'],flush=True)
        native=[str(binary),str(recipe),str(row['steps']),str(row['seconds'])]
        unit=None;command=native
        if p.get('task_cgroup'):
            unit=f"marketforge-price-{out.name}-s{row['seed']}-{row['profile']}-{os.getpid()}"
            command=['systemd-run','--quiet','--wait','--pipe','--collect','--unit='+unit,
                '--property=WorkingDirectory='+str(ROOT),'--property=TimeoutStopSec=5s','--property=KillMode=control-group']
            command+=['--property='+k+'='+v for k,v in p['task_cgroup'].items()]
            command+=['--setenv='+k+'='+env[k]for k in ('RESEARCH_PLUGIN_WAKES','MARKETFORGE_PINE_IN_PROCESS','MARKETFORGE_PINE_REPLAY_STATE','MARKETFORGE_BOT_WORKERS','RAYON_NUM_THREADS')]
            command+=native
        with receipt.open('wb')as stdout,(out/(row['name']+'.log')).open('wb')as stderr:
            child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
            result.update(pid=child.pid,command=command,task_cgroup=p.get('task_cgroup'),unit=unit);peak=0;swap_peak=0
            while child.poll()is None:
                m=memory();status=Path(f'/proc/{child.pid}/status')
                group=Path('/sys/fs/cgroup/system.slice')/(unit+'.service')if unit else None
                if group and group.exists():
                    try:
                        peak=max(peak,int((group/'memory.peak').read_text())//1024)
                        swap_peak=max(swap_peak,int((group/'memory.swap.current').read_text())//1024)
                        m['group_events']=(group/'memory.events').read_text()
                    except FileNotFoundError:pass
                elif status.exists():
                    rss=next((int(r.split()[1])for r in status.read_text().splitlines()if r.startswith('VmRSS:')),0);peak=max(peak,rss)
                with (out/'resource-samples.jsonl').open('a')as f:f.write(json.dumps(dict(time=time.time(),pid=child.pid,peak_memory_kib=peak,peak_swap_kib=swap_peak,**m))+'\n')
                if min(m['linux_available_kib'],m['host_free_commit_kib'])<3*1024*1024 or time.monotonic()-start>10800:
                    if unit:subprocess.run(['systemctl','stop',unit],check=False)
                    else:child.kill()
                    result['failure']='Owned Linux child stopped: memory below3GiB or3h timeout';break
                time.sleep(10)
            result.update(exit_code=child.wait(),peak_memory_kib=peak,peak_swap_kib=swap_peak)
        result['wall_seconds']=time.monotonic()-start
        finish_result(result,receipt,row)
        write(done,result);print(json.dumps(result),flush=True);assert result['complete']


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('directory');p.add_argument('--seed',type=int);a=p.parse_args();run(a.directory,a.seed)
